package com.khanu.lisaa.brain

import com.khanu.lisaa.command.Command
import com.khanu.lisaa.command.CommandInterpreter
import com.khanu.lisaa.data.repository.MemoryRepository
import com.khanu.lisaa.emotion.EmotionEngine
import com.khanu.lisaa.personality.GreetingContext
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.personality.MoodDetector
import com.khanu.lisaa.personality.PersonalityEngine
import com.khanu.lisaa.relationship.RelationshipEngine
import com.khanu.lisaa.relationship.RelationshipMode
import com.khanu.lisaa.util.Constants
import kotlin.random.Random
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LisaaBrain(
    private val repository: MemoryRepository,
    private val appOpener: (String) -> Boolean,
    private val searcher: (String) -> Unit
) {
    private val personality = PersonalityEngine()
    private val context = ConversationContext()

    private lateinit var relationshipEngine: RelationshipEngine
    private lateinit var emotionEngine: EmotionEngine

    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())

    private val jealousyTriggerWords = listOf(
        "dost ke sath", "kisi aur se baat", "kisi se milne", "date pe",
        "girlfriend", "boyfriend"
    )

    private val defaultConversationalReplies = listOf(
        "Haanji, main sun rahi hoon!",
        "Mera poora dhyan aapki taraf hai, boliye.",
        "Aapki aawaz sunkar accha laga!",
        "Main aapke liye kya kar sakti hoon?",
        "Haanji bataiye, main bilkul tayaar hoon."
    )

    suspend fun loadContext() {
        repository.lastMood()?.let { context.updateMood(it) }
        context.focusModeUntil = repository.getFocusModeUntil()
        context.userName = repository.getUserName()
        context.isFirstEverSession = repository.conversationCount() == 0
        context.lastSeenAt = repository.getLastSeenAt()

        relationshipEngine = RelationshipEngine(
            mode = repository.getRelationshipMode(),
            trust = repository.getTrustLevel(),
            attachment = repository.getAttachmentLevel()
        )
        emotionEngine = EmotionEngine(warmth = repository.getWarmth())

        if (context.lastSeenAt != 0L) {
            val hoursSinceLastSeen = (System.currentTimeMillis() - context.lastSeenAt) / 3_600_000L
            relationshipEngine.onNewSession()
            emotionEngine.applyInactivityDecay(hoursSinceLastSeen)
            persistRelationshipState()
            persistEmotionState()
        }
    }

    fun containsWakeWord(text: String): Boolean = matchWakeWord(text) != null

    suspend fun handleUtterance(rawText: String): BrainResult? {
        if (rawText.isBlank()) return null

        val wake = matchWakeWord(rawText)
        val commandText = if (wake != null) {
            rawText.replace(wake, "").trim()
        } else {
            rawText.trim()
        }

        val result = if (commandText.isBlank()) {
            handleGreeting(rawText)
        } else {
            processCommand(commandText)
        }
        touchLastSeen()
        return result
    }

    private fun matchWakeWord(text: String): String? =
        Constants.WAKE_WORDS.firstOrNull { text.contains(it, ignoreCase = true) }

    private suspend fun handleGreeting(rawText: String): BrainResult {
        val hoursSinceLastSeen = if (context.lastSeenAt == 0L) {
            0L
        } else {
            (System.currentTimeMillis() - context.lastSeenAt) / 3_600_000L
        }
        val greetingContext = GreetingContext(
            recentMood = context.recentMood,
            userName = context.userName,
            isFirstMeeting = context.isFirstEverSession,
            isLongAbsence = !context.isFirstEverSession && hoursSinceLastSeen >= EmotionEngine.LONG_GAP_HOURS,
            relationshipMode = relationshipEngine.currentMode(),
            affectionTier = relationshipEngine.affectionTier()
        )
        val reply = personality.greeting(greetingContext)
        context.isFirstEverSession = false

        val toneMood = emotionEngine.toneMood()
        repository.remember(rawText, reply, toneMood)
        return BrainResult(reply, toneMood)
    }

    private suspend fun processCommand(commandText: String): BrainResult {
        val now = System.currentTimeMillis()
        val mood = MoodDetector.detect(commandText)
        val isRepeat = commandText == context.lastCommandText &&
            (now - context.lastCommandTime) < Constants.REPEAT_COMMAND_WINDOW_MS
        val focusActive = now < context.focusModeUntil

        context.updateMood(mood)
        emotionEngine.reactTo(mood)
        persistEmotionState()

        if (mood == Mood.WORKING) {
            context.focusModeUntil = now + Constants.FOCUS_MODE_DURATION_MS
            repository.setFocusModeUntil(context.focusModeUntil)
        }

        val command = CommandInterpreter.parse(commandText)
        var reply = when (command) {
            is Command.Time -> personality.wrapTime(timeFormat.format(Date()))
            is Command.Date -> personality.wrapDate(dateFormat.format(Date()))
            is Command.Note -> handleNote(command.text)
            is Command.OpenApp -> handleOpenApp(command.appName)
            is Command.Search -> handleSearch(command.query)
            is Command.Joke -> {
                repository.recordUsage("joke")
                personality.wrapJoke()
            }
            is Command.Goodbye ->
                personality.farewell(relationshipEngine.currentMode(), relationshipEngine.affectionTier())
            is Command.SetName -> handleSetName(command.name)
            is Command.LikeSomething -> handleLikeSomething(command.thing)
            is Command.SetRelationshipMode -> handleSetRelationshipMode(command.modeKeyword)
            is Command.Unknown -> handleConversational(commandText, mood, focusActive)
        }

        // Guarantee response: agar reply kisi wajah se empty reh jaye
        if (reply.isBlank()) {
            reply = defaultConversationalReplies.random()
        }

        val isFunctionalCommand = command !is Command.Unknown && command !is Command.Goodbye
        val emotionalMoods = setOf(Mood.SAD, Mood.LONELY, Mood.ANGRY, Mood.TIRED)
        val followUpMoods = setOf(Mood.SAD, Mood.LONELY, Mood.ANGRY)

        reply = when {
            isRepeat -> "${personality.annoyedRepeat()} $reply"
            isFunctionalCommand && mood in emotionalMoods -> personality.attachEmotionalAside(reply, mood)
            !isFunctionalCommand && mood in followUpMoods ->
                personality.maybeAddFollowUp(reply, mood, context.moodStreak)
            else -> personality.maybeAddTease(reply, mood, focusActive)
        }

        context.lastCommandText = commandText
        context.lastCommandTime = now

        repository.remember(commandText, reply, mood)
        return BrainResult(reply, mood)
    }

    private suspend fun handleConversational(commandText: String, mood: Mood, focusActive: Boolean): String {
        if (relationshipEngine.jealousyEligible() && mentionsOtherPerson(commandText) &&
            Random.nextInt(100) < 40
        ) {
            return personality.wrapJealousy()
        }

        if (mood == Mood.NEUTRAL && !focusActive && Random.nextInt(100) < 15) {
            val likes = repository.getLikes()
            if (likes.isNotEmpty()) {
                return personality.wrapRecallLike(likes.random())
            }
        }

        val baseReply = personality.wrapConversational(mood, focusActive)
        return if (baseReply.isNotBlank()) baseReply else defaultConversationalReplies.random()
    }

    private fun mentionsOtherPerson(text: String): Boolean {
        val t = text.lowercase(Locale.getDefault())
        return jealousyTriggerWords.any { t.contains(it) }
    }

    private suspend fun handleNote(text: String): String {
        if (text.isNotBlank()) {
            val category = inferNoteCategory(text)
            repository.addNote(text, category = category)
            repository.recordUsage("note")
            if (category != "general") {
                relationshipEngine.onPersonalDisclosure()
                persistRelationshipState()
            }
        }
        return personality.wrapNote(text)
    }

    private fun inferNoteCategory(text: String): String {
        val t = text.lowercase(Locale.getDefault())
        return when {
            t.contains("goal") || t.contains("target") -> "goal"
            t.contains("project") -> "project"
            else -> "general"
        }
    }

    private suspend fun handleSetName(name: String): String {
        if (name.isBlank()) return personality.wrapSetNameEmpty()
        val cleanName = name.trim().split(" ").firstOrNull()
            ?.replaceFirstChar { it.uppercase() } ?: return personality.wrapSetNameEmpty()
        repository.setUserName(cleanName)
        context.userName = cleanName
        relationshipEngine.onPersonalDisclosure()
        persistRelationshipState()
        return personality.wrapSetName(cleanName)
    }

    private suspend fun handleLikeSomething(thing: String): String {
        if (thing.isBlank()) return personality.wrapLikeEmpty()
        repository.addNote(thing, category = "like")
        relationshipEngine.onPersonalDisclosure()
        persistRelationshipState()
        return personality.wrapLikeSaved(thing)
    }

    private suspend fun handleSetRelationshipMode(modeKeyword: String): String {
        val newMode = if (modeKeyword == "romantic") RelationshipMode.ROMANTIC else RelationshipMode.FRIEND
        relationshipEngine.setMode(newMode)
        persistRelationshipState()
        return personality.wrapRelationshipModeChanged(newMode)
    }

    private suspend fun handleOpenApp(appName: String): String {
        if (appName.isBlank()) return personality.wrapOpenAppEmpty()
        val found = appOpener(appName)
        return if (found) {
            repository.recordUsage("open:$appName")
            personality.wrapOpenAppFound(appName)
        } else {
            personality.wrapOpenAppNotFound(appName)
        }
    }

    private suspend fun handleSearch(query: String): String {
        if (query.isBlank()) return personality.wrapSearchEmpty()
        searcher(query)
        repository.recordUsage("search")
        return personality.wrapSearch(query)
    }

    private suspend fun persistRelationshipState() {
        repository.setRelationshipMode(relationshipEngine.currentMode())
        repository.setTrustLevel(relationshipEngine.trustLevel())
        repository.setAttachmentLevel(relationshipEngine.attachmentLevel())
    }

    private suspend fun persistEmotionState() {
        repository.setWarmth(emotionEngine.currentWarmth())
    }

    private suspend fun touchLastSeen() {
        context.lastSeenAt = System.currentTimeMillis()
        repository.setLastSeenAt(context.lastSeenAt)
    }
}
