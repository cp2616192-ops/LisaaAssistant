package com.khanu.lisaa.command

/**
 * User ke bole gaye command ka structured (typed) form.
 * Sealed class hone ki wajah se jahan bhi ye use hota hai, Kotlin compiler
 * `when` block ko exhaustive check karta hai — koi case miss nahi ho sakta.
 */
sealed class Command {
    object Time : Command()
    object Date : Command()
    object Joke : Command()
    object Goodbye : Command()
    data class Note(val text: String) : Command()
    data class OpenApp(val appName: String) : Command()
    data class Search(val query: String) : Command()
    data class SetName(val name: String) : Command()

    /** Koi functional command match nahi hua — ye ek conversational utterance hai. */
    data class Unknown(val rawText: String) : Command()
}
