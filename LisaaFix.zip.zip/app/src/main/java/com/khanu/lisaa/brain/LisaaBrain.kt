package com.khanu.lisaa.brain

import com.khanu.lisaa.command.Command
import com.khanu.lisaa.command.CommandInterpreter
import com.khanu.lisaa.data.repository.MemoryRepository
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.personality.MoodDetector
import com.khanu.lisaa.personality.PersonalityEngine
import com.khanu.lisaa.util.Constants
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Lisaa ka "dimaag" — poori conversation ka orchestrator.
 *
 * Ye class Module 1 (CommandInterpreter, MoodDetector, PersonalityEngine) aur
 * Module 2 (MemoryRepository) ko jodti hai, aur Service ko sirf ek saaf
 * [BrainResult] deti hai — bolna kya hai, kis mood me. Service isse sirf itna
 * maangta hai; mic/TTS/notification jaisi Android-specific cheezon se ye class
 * bilkul anjaan hai (isliye testable hai — koi Context/Service dependency nahi).
 *
 * Responsibilities (Module 3 spec ke mutabik):
 *  - Conversation Flow: [handleUtterance] wake-word se lekar reply tak
 *  - Emotion Engine: [MoodDetector] ka orchestration
 *  - Memory Context: [ConversationContext] + [MemoryRepository]
 *  - Personality Engine: [PersonalityEngine] ka orchestration
 *  - Mood Detection: [MoodDetector] ka orchestration
 *  - Response Selection: PersonalityEngine se sahi reply chunna
 *  - Command Routing: [CommandInterpreter] ke Command par based routing
 *  - Context Awareness: mood streak, repeat-command detection, focus mode
 *
 * @param appOpener Real app-launch action Service se inject hoti hai (PackageManager
 *                  access chahiye, isliye ye Brain ke andar nahi ho sakta) — true
 *                  return karta hai agar app mil gaya aur khul gaya.
 * @param searcher  Real web-search action, Service se inject.
 */
class LisaaBrain(
    private val repository: MemoryRepository,
    private val appOpener: (String) -> Boolean,
    private val searcher: (String) -> Unit
) {
    private val personality = PersonalityEngine()
    private val context = ConversationContext()

    // Reuse: har command par naya SimpleDateFormat banana zaroori nahi — object reuse
    // se thoda GC pressure kam hota hai (Module 3 performance pass ka hissa).
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())

    /** Service startup par pichla context (mood, focus mode, naam) memory se load karta hai. */
    suspend fun loadContext() {
        repository.lastMood()?.let { context.updateMood(it) }
        context.focusModeUntil = repository.getFocusModeUntil()
        context.userName = repository.getUserName()
        context.isFirstEverSession = repository.conversationCount() == 0
    }

    /**
     * Fast, non-suspending check — Service isse turant wake-word acknowledgment
     * (activation tone/vibration) ke liye use karta hai, [handleUtterance] chalne
     * se pehle hi.
     */
    fun containsWakeWord(text: String): Boolean = matchWakeWord(text) != null

    /**
     * Poora recognized utterance process karta hai. Wake word na mile to null
     * return karta hai (Service ko chupchap sunte rehna chahiye).
     */
    suspend fun handleUtterance(rawText: String): BrainResult? {
        val wake = matchWakeWord(rawText) ?: return null
        val commandText = rawText.replace(wake, "").trim()

        return if (commandText.isBlank()) {
            val reply = personality.greeting(context.recentMood, context.userName, context.isFirstEverSession)
            context.isFirstEverSession = false
            repository.remember(rawText, reply, Mood.NEUTRAL)
            BrainResult(reply, Mood.NEUTRAL)
        } else {
            processCommand(commandText)
        }
    }

    private fun matchWakeWord(text: String): String? =
        Constants.WAKE_WORDS.firstOrNull { text.contains(it) }

    private suspend fun processCommand(commandText: String): BrainResult {
        val now = System.currentTimeMillis()
        val mood = MoodDetector.detect(commandText)
        val isRepeat = commandText == context.lastCommandText &&
            (now - context.lastCommandTime) < Constants.REPEAT_COMMAND_WINDOW_MS
        val focusActive = now < context.focusModeUntil

        // Mood streak isi utterance ke hisaab se update — reply-shaping se pehle,
        // taaki follow-up-question logic sahi streak count dekhe.
        context.updateMood(mood)

        if (mood == Mood.WORKING) {
            context.focusModeUntil = now + Constants.FOCUS_MODE_DURATION_MS
            repository.setFocusModeUntil(context.focusModeUntil)
        }

        val command = CommandInterpreter.parse(commandText)
        var reply = when (command) {
            is Command.Time -> personality.wrapTime(timeFormat.format(Date()))
            is Command.Date -> personality.wrapDate(dateFormat.format(Date()))
            is Command.Note -> handleNote(command.text)
            is Command.OpenApp -> handleOpenApp(command.appName)
            is Command.Search -> handleSearch(command.query)
            is Command.Joke -> {
                repository.recordUsage("joke")
                personality.wrapJoke()
            }
            is Command.Goodbye -> personality.farewell()
            is Command.SetName -> handleSetName(command.name)
            is Command.Unknown -> personality.wrapConversational(mood, focusActive)
        }

        // Priority: repeat-annoyance > emotional aside (functional command + strong
        // mood) > follow-up question (conversational + repeated emotional streak) >
        // light tease. Sirf ek hi extra kabhi lagti hai, taaki reply overloaded na ho.
        val isFunctionalCommand = command !is Command.Unknown && command !is Command.Goodbye
        val emotionalMoods = setOf(Mood.SAD, Mood.LONELY, Mood.ANGRY, Mood.TIRED)
        val followUpMoods = setOf(Mood.SAD, Mood.LONELY, Mood.ANGRY)

        reply = when {
            isRepeat -> "${personality.annoyedRepeat()} $reply"
            isFunctionalCommand && mood in emotionalMoods -> personality.attachEmotionalAside(reply, mood)
            !isFunctionalCommand && mood in followUpMoods ->
                personality.maybeAddFollowUp(reply, mood, context.moodStreak)
            else -> personality.maybeAddTease(reply, mood, focusActive)
        }

        context.lastCommandText = commandText
        context.lastCommandTime = now

        repository.remember(commandText, reply, mood)
        return BrainResult(reply, mood)
    }

    private suspend fun handleNote(text: String): String {
        if (text.isNotBlank()) {
            repository.addNote(text, category = inferNoteCategory(text))
            repository.recordUsage("note")
        }
        return personality.wrapNote(text)
    }

    /** Note ke text me "goal"/"target"/"project" jaise keywords dekh kar category tag karta hai. */
    private fun inferNoteCategory(text: String): String {
        val t = text.lowercase(Locale.getDefault())
        return when {
            t.contains("goal") || t.contains("target") -> "goal"
            t.contains("project") -> "project"
            else -> "general"
        }
    }

    private suspend fun handleSetName(name: String): String {
        if (name.isBlank()) return personality.wrapSetNameEmpty()
        val cleanName = name.trim().split(" ").firstOrNull()
            ?.replaceFirstChar { it.uppercase() } ?: return personality.wrapSetNameEmpty()
        repository.setUserName(cleanName)
        context.userName = cleanName
        return personality.wrapSetName(cleanName)
    }

    private suspend fun handleOpenApp(appName: String): String {
        if (appName.isBlank()) return personality.wrapOpenAppEmpty()
        val found = appOpener(appName)
        return if (found) {
            repository.recordUsage("open:$appName")
            personality.wrapOpenAppFound(appName)
        } else {
            personality.wrapOpenAppNotFound(appName)
        }
    }

    private suspend fun handleSearch(query: String): String {
        if (query.isBlank()) return personality.wrapSearchEmpty()
        searcher(query)
        repository.recordUsage("search")
        return personality.wrapSearch(query)
    }
}
