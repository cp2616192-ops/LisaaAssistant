package com.khanu.lisaa.personality

import kotlin.random.Random

/**
 * Lisaa ki "shakhsiyat" (personality) yahan se aati hai. Ye class jaan-boojh kar
 * Android se bilkul independent rakhi gayi hai (koi Context, koi TTS, koi Service
 * dependency nahi) — isliye plain JUnit test likhna aasan hai. LisaaBrain isse
 * text maangta hai; final decision "kya bolna hai" hamesha yahin se aata hai.
 */
class PersonalityEngine {

    /**
     * Sirf wake word bola gaya, koi command nahi — random greeting, kabhi na dohrane
     * wali. Pehli-hi baar (is device par kabhi baat na hui ho) special welcome deti
     * hai; uske baad naam pata ho to kabhi kabhi naam se bulati hai.
     */
    fun greeting(recentMood: Mood?, userName: String?, isFirstMeeting: Boolean): String {
        if (isFirstMeeting) {
            return ResponseBank.pick("first_meeting", ResponseBank.firstMeetingGreetings)
        }

        // Agar pichli baar user sad/lonely/tired tha, kabhi kabhi thoda caring greeting dikhao
        val emotionalLastTime = recentMood == Mood.SAD || recentMood == Mood.LONELY || recentMood == Mood.TIRED
        if (emotionalLastTime && Random.nextInt(100) < 35) {
            return ResponseBank.pick("caring_greeting", ResponseBank.caringGreetings)
        }

        if (!userName.isNullOrBlank() && Random.nextInt(100) < 40) {
            return ResponseBank.pick("named_greeting", ResponseBank.namedGreetings).format(userName)
        }

        return ResponseBank.pick("greeting", ResponseBank.greetings)
    }

    fun wrapSetName(name: String): String =
        ResponseBank.pick("set_name", ResponseBank.setNameTemplates).format(name)

    fun wrapSetNameEmpty(): String =
        ResponseBank.pick("set_name_empty", ResponseBank.setNameEmptyTemplates)

    /** Random goodbye — "bye"/"alvida" jaise commands par. */
    fun farewell(): String = ResponseBank.pick("goodbye", ResponseBank.goodbyes)

    fun wrapTime(timeValue: String): String =
        ResponseBank.pick("time", ResponseBank.timeTemplates).format(timeValue)

    fun wrapDate(dateValue: String): String =
        ResponseBank.pick("date", ResponseBank.dateTemplates).format(dateValue)

    fun wrapNote(noteText: String): String =
        if (noteText.isBlank()) {
            ResponseBank.pick("note_empty", ResponseBank.noteEmptyTemplates)
        } else {
            ResponseBank.pick("note", ResponseBank.noteTemplates).format(noteText)
        }

    fun wrapOpenAppFound(appName: String): String =
        ResponseBank.pick("open_found", ResponseBank.openFoundTemplates).format(appName)

    fun wrapOpenAppNotFound(appName: String): String =
        ResponseBank.pick("open_not_found", ResponseBank.openNotFoundTemplates).format(appName)

    fun wrapOpenAppEmpty(): String =
        ResponseBank.pick("open_empty", ResponseBank.openEmptyTemplates)

    fun wrapSearch(query: String): String =
        ResponseBank.pick("search", ResponseBank.searchTemplates).format(query)

    fun wrapSearchEmpty(): String =
        ResponseBank.pick("search_empty", ResponseBank.searchEmptyTemplates)

    fun wrapJoke(): String = ResponseBank.pick("joke", ResponseBank.jokes)

    /**
     * Jab koi functional command match nahi hua — mood ke hisaab se natural
     * baat-cheet. NEUTRAL casual replies me kabhi kabhi ek thinking-word
     * ("Hmm...", "Achha...") prefix hoti hai taaki bilkul insaan jaisa lage.
     */
    fun wrapConversational(mood: Mood, focusModeActive: Boolean): String = when (mood) {
        Mood.SAD -> ResponseBank.pick("comfort", ResponseBank.comfort)
        Mood.LONELY -> ResponseBank.pick("lonely_comfort", ResponseBank.lonelyComfort)
        Mood.HAPPY -> ResponseBank.pick("celebrate", ResponseBank.celebrate)
        Mood.EXCITED -> ResponseBank.pick("excited_celebrate", ResponseBank.excitedCelebrate)
        Mood.ANGRY -> ResponseBank.pick("calm", ResponseBank.calm)
        Mood.TIRED -> ResponseBank.pick("rest", ResponseBank.rest)
        Mood.WORKING -> ResponseBank.pick("focus", ResponseBank.focusSupport)
        Mood.RELAXED -> ResponseBank.pick("relaxed_chat", ResponseBank.relaxedChat)
        Mood.NEUTRAL -> if (focusModeActive) {
            ResponseBank.pick("focus", ResponseBank.focusSupport)
        } else {
            val base = if (Random.nextInt(100) < 50) {
                ResponseBank.pick("filler", ResponseBank.neutralFiller)
            } else {
                ResponseBank.pick("fallback", ResponseBank.honestFallback)
            }
            maybePrefixThinkingWord(base)
        }
    }

    /** Repeat command par halki playful naaraazgi — kabhi rude nahi. */
    fun annoyedRepeat(): String = ResponseBank.pick("annoyance", ResponseBank.playfulAnnoyance)

    /**
     * Jab ek functional command (time/date/note/etc.) ke sath user ka mood bhi
     * sad/lonely/angry/tired dikhe, to seedha data de dene ke baad ek chhoti
     * caring line jod deti hai — taaki wo sirf ek "command executor" na lage.
     */
    fun attachEmotionalAside(baseReply: String, mood: Mood): String {
        val asideBank = when (mood) {
            Mood.SAD -> ResponseBank.sadAside
            Mood.LONELY -> ResponseBank.lonelyAside
            Mood.ANGRY -> ResponseBank.angryAside
            Mood.TIRED -> ResponseBank.tiredAside
            else -> return baseReply
        }
        val aside = ResponseBank.pick("aside_${mood.name}", asideBank)
        return "$baseReply $aside"
    }

    /**
     * Agar user lagataar (2+ baar) sad/lonely/angry mood me hai, to comfort line
     * ke sath ek chhota follow-up sawaal bhi jod deti hai — taaki Lisaa genuinely
     * interested lage, sirf scripted comfort nahi de rahi.
     */
    fun maybeAddFollowUp(baseReply: String, mood: Mood, moodStreak: Int): String {
        val eligibleMood = mood == Mood.SAD || mood == Mood.LONELY || mood == Mood.ANGRY
        if (!eligibleMood || moodStreak < 2) return baseReply
        val followUp = ResponseBank.pick("follow_up", ResponseBank.followUpQuestions)
        return "$baseReply $followUp"
    }

    /**
     * Kabhi kabhi (~20% chance) ek chhoti chhed-chhaad line jod deta hai taaki
     * replies mechanical na lagein. Focus mode ya emotional (sad/lonely/angry/
     * tired) moments mein tease nahi karti — timing sahi hona zaroori hai.
     */
    fun maybeAddTease(baseReply: String, mood: Mood, focusModeActive: Boolean): String {
        val appropriateMood = mood == Mood.NEUTRAL || mood == Mood.HAPPY ||
            mood == Mood.EXCITED || mood == Mood.RELAXED
        if (!appropriateMood || focusModeActive) return baseReply
        if (Random.nextInt(100) >= 20) return baseReply
        val tease = ResponseBank.pick("tease", ResponseBank.teasing)
        return "$baseReply $tease"
    }

    /** ~15% chance casual replies se pehle ek natural "sochne" jaisa opener word. */
    private fun maybePrefixThinkingWord(reply: String): String {
        if (Random.nextInt(100) >= 15) return reply
        val opener = ResponseBank.pick("opener", ResponseBank.thinkingOpeners)
        return "$opener $reply"
    }
}
