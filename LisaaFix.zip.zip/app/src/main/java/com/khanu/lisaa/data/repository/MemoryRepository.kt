package com.khanu.lisaa.data.repository

import android.content.Context
import com.khanu.lisaa.data.LisaaDatabase
import com.khanu.lisaa.data.entity.CommandUsageEntity
import com.khanu.lisaa.data.entity.ConversationEntity
import com.khanu.lisaa.data.entity.NoteEntity
import com.khanu.lisaa.data.entity.PreferenceEntity
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.util.Constants
import kotlinx.coroutines.flow.Flow

/**
 * Single source of truth Lisaa ki memory ke liye. Service (aur aage chal kar
 * ViewModel) seedhe Room DAO se baat nahi karte — sab isi Repository se guzarta
 * hai. Ye Repository pattern hai (MVVM ka "Model" layer), taaki data-access
 * logic ek hi jagah rahe aur duplicate na ho.
 */
class MemoryRepository(context: Context) {

    private val db = LisaaDatabase.getInstance(context)

    // ---------- Conversation history (long-term memory) ----------

    /** Ek conversation turn ko permanently save karta hai, aur history ko trim rakhta hai. */
    suspend fun remember(userText: String, lisaaReply: String, mood: Mood) {
        db.conversationDao().insert(
            ConversationEntity(userText = userText, lisaaReply = lisaaReply, mood = mood.name)
        )
        db.conversationDao().trimTo(Constants.MAX_MEMORY_ENTRIES)
    }

    /** Pichli baar ka mood — greeting personalize karne ke liye use hota hai. */
    suspend fun lastMood(): Mood? =
        db.conversationDao().getLast()?.mood?.let { runCatching { Mood.valueOf(it) }.getOrNull() }

    suspend fun recentHistory(limit: Int = 20): List<ConversationEntity> =
        db.conversationDao().getRecent(limit)

    suspend fun conversationCount(): Int = db.conversationDao().count()

    /** Reactive — ViewModel isse UI me live "N baatein yaad hain" jaisa counter dikhane ke liye collect karta hai. */
    fun observeConversationCount(): Flow<Int> = db.conversationDao().observeCount()

    // ---------- Notes ----------

    /** category = "goal" / "project" / "general" — LisaaBrain isse note ke text se infer karta hai. */
    suspend fun addNote(text: String, category: String = "general") {
        db.noteDao().insert(NoteEntity(text = text, category = category))
    }

    suspend fun getAllNotes(): List<String> =
        db.noteDao().getAll().map { it.text }

    /** Reactive — goals/projects/notes screen (future) isse live updates paayega. */
    fun observeNotes(): Flow<List<NoteEntity>> = db.noteDao().observeAll()

    // ---------- Usage stats (frequently used commands / favourite apps) ----------

    /** Har baar ek functional command execute hone par call hota hai — count badhata hai. */
    suspend fun recordUsage(actionKey: String) {
        val existing = db.commandUsageDao().get(actionKey)
        db.commandUsageDao().upsert(
            CommandUsageEntity(
                actionKey = actionKey,
                count = (existing?.count ?: 0) + 1,
                lastUsed = System.currentTimeMillis()
            )
        )
    }

    suspend fun getTopUsedCommands(limit: Int = 5): List<CommandUsageEntity> =
        db.commandUsageDao().getTopUsed(limit)

    /**
     * "Favourite apps" — ek explicit "mera favourite app X hai" command banane ke bajaye,
     * hum actual usage se derive karte hain (jo behaviour se aata hai, wahi zyada sach hai
     * kisi ek baar bole gaye declaration se). "open:whatsapp" jaisi keys yahan se milti hain.
     */
    suspend fun getFavoriteApps(limit: Int = 5): List<String> =
        getTopUsedCommands(20)
            .filter { it.actionKey.startsWith("open:") }
            .sortedByDescending { it.count }
            .take(limit)
            .map { it.actionKey.removePrefix("open:") }

    // ---------- User preferences (survive app/service restarts) ----------

    suspend fun setPreference(key: String, value: String) {
        db.preferenceDao().set(PreferenceEntity(prefKey = key, prefValue = value))
    }

    suspend fun getPreference(key: String): String? = db.preferenceDao().get(key)

    /** Focus mode (kaam/stress detect hone par kam disturb karna) restart ke baad bhi yaad rehta hai. */
    suspend fun setFocusModeUntil(timestamp: Long) =
        setPreference(KEY_FOCUS_MODE_UNTIL, timestamp.toString())

    suspend fun getFocusModeUntil(): Long =
        getPreference(KEY_FOCUS_MODE_UNTIL)?.toLongOrNull() ?: 0L

    /** User ka naam — "mera naam X hai" se capture hota hai, restart ke baad bhi yaad rehta hai. */
    suspend fun setUserName(name: String) = setPreference(KEY_USER_NAME, name)

    suspend fun getUserName(): String? = getPreference(KEY_USER_NAME)

    companion object {
        private const val KEY_FOCUS_MODE_UNTIL = "focus_mode_until"
        private const val KEY_USER_NAME = "user_name"
    }
}
