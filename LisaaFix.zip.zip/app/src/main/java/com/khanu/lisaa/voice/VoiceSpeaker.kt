package com.khanu.lisaa.voice

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.util.Constants
import java.util.Locale
import kotlin.random.Random

/**
 * Text-to-speech wrapper. Do cheezein add karta hai jo default Android TTS
 * khud nahi karta:
 *
 *  1. Bolne se pehle ek chhota, random "sochne" jaisa pause (reply jitna lamba,
 *     utna hi thoda zyada pause) — taaki jawab turant/mechanical na aaye.
 *  2. Mood ke hisaab se pitch/speed adjust karna — udaas/akela/thaka hua mood
 *     me dheemi aur naram awaaz, excited/happy me thodi zyada energetic.
 *  3. Bolna shuru hone se theek pehle ek chhoti "breathing" silence (TTS ki apni
 *     queue mein), mood ke hisaab se lambi/chhoti — insaan jaisi natural saans.
 *
 * Audio focus request karta hai speak karne se pehle taaki doosre app ka audio
 * overlap na ho — ye clipping/echo kam karne ka real, available mechanism hai
 * (asli "noise cancellation" nahi, lekin audio collision avoid karta hai).
 *
 * HONEST NOTE: Female voice selection best-effort hai — Android ka TTS API
 * voice ka gender reliably expose nahi karta. Hum voice name me "female"
 * dhoondte hain; na mile to engine ki default hi-IN voice use hoti hai (Google
 * ka Hindi voice usually default female hoti hai). "Crystal clear" audio
 * quality khud device/engine par depend karti hai — app us par seedha control
 * nahi rakhta, sirf pitch/rate/voice choice tak hi control hai.
 */
class VoiceSpeaker(
    context: Context,
    private val onReadyToListenAgain: () -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    // Deprecated overload use ho raha hai (minSdk 26 compatible, simple transient
    // focus ke liye kaafi hai) — isliye ek real listener chahiye, null nahi.
    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { /* no-op */ }

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        tts?.language = Locale("hi", "IN")
        selectFemaleVoiceIfAvailable()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                abandonAudioFocus()
                handler.postDelayed({ onReadyToListenAgain() }, 250)
            }

            override fun onError(utteranceId: String?) {
                abandonAudioFocus()
                handler.postDelayed({ onReadyToListenAgain() }, 250)
            }
        })
        ready = true
    }

    private fun selectFemaleVoiceIfAvailable() {
        val engine = tts ?: return
        val candidate: Voice? = runCatching {
            engine.voices?.firstOrNull {
                it.locale.language == "hi" && it.name.lowercase(Locale.US).contains("female")
            } ?: engine.voices?.firstOrNull {
                it.locale.language == "en" && it.name.lowercase(Locale.US).contains("female")
            }
        }.getOrNull()
        candidate?.let { engine.voice = it }
    }

    /** Reply bolti hai — thinking-delay, audio focus, aur mood-tuned pitch/rate ke sath. */
    fun speak(text: String, mood: Mood) {
        if (!ready) {
            handler.postDelayed({ speak(text, mood) }, 300)
            return
        }
        val lengthBonus = text.length.coerceAtMost(120) * 2L
        val baseDelay = Random.nextLong(Constants.THINKING_DELAY_MIN_MS, Constants.THINKING_DELAY_MAX_MS)
        val thinkingDelay = baseDelay + lengthBonus

        handler.postDelayed({
            requestAudioFocus()
            applyMoodTone(mood)
            // Har call ko unique utteranceId — overlapping utterances kabhi ek doosre
            // ke onDone callback se confuse na hon (speech-loop/repeat bug prevention).
            val utteranceId = "${Constants.TTS_UTTERANCE_ID}_${System.nanoTime()}"

            // Engine ki max-length limit se zyada text bhejne par TTS ERROR de sakta
            // hai — is guard se wo edge case bhi crash/silent-fail nahi karta.
            val maxLen = TextToSpeech.getMaxSpeechInputLength()
            val safeText = if (text.length > maxLen) text.take((maxLen - 1).coerceAtLeast(0)) else text

            // Bolna shuru hone se theek pehle ek chhoti "breathing" silence — TTS ki
            // apni queue mein hi (Handler-delay se alag), taaki bilkul insaan jaisa
            // lage. Mood ke hisaab se lambi/chhoti hoti hai.
            tts?.playSilentUtterance(breathPauseFor(mood), TextToSpeech.QUEUE_FLUSH, null)
            tts?.speak(safeText, TextToSpeech.QUEUE_ADD, null, utteranceId)
        }, thinkingDelay)
    }

    /** Udaas/akela/thaka hua mood me thodi lambi saans; excited/happy me chhoti. */
    private fun breathPauseFor(mood: Mood): Long = when (mood) {
        Mood.SAD, Mood.LONELY, Mood.TIRED -> Constants.BREATH_PAUSE_MAX_MS
        Mood.EXCITED, Mood.HAPPY -> Constants.BREATH_PAUSE_MIN_MS
        else -> (Constants.BREATH_PAUSE_MIN_MS + Constants.BREATH_PAUSE_MAX_MS) / 2
    }

    private fun applyMoodTone(mood: Mood) {
        val (pitch, rate) = when (mood) {
            Mood.SAD, Mood.LONELY, Mood.TIRED -> 0.95f to 0.90f
            Mood.HAPPY -> 1.08f to 1.05f
            Mood.EXCITED -> 1.12f to 1.10f
            Mood.ANGRY -> 0.98f to 0.95f
            Mood.WORKING -> 1.0f to 1.0f
            Mood.RELAXED -> 1.0f to 0.95f
            Mood.NEUTRAL -> 1.02f to 1.0f
        }
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
    }

    private fun requestAudioFocus() {
        @Suppress("DEPRECATION")
        audioManager?.requestAudioFocus(
            focusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        )
    }

    private fun abandonAudioFocus() {
        @Suppress("DEPRECATION")
        audioManager?.abandonAudioFocus(focusChangeListener)
    }

    fun shutdown() {
        abandonAudioFocus()
        tts?.stop()
        tts?.shutdown()
        handler.removeCallbacksAndMessages(null)
    }
}
package com.khanu.lisaa.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Locale

class VoiceSpeaker(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isReady = false
    private var pendingText: String? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
            isReady = true
            Log.d("VoiceSpeaker", "TTS Engine Ready!")
            
            // Agar TTS banne se pehle koi text bolne ko mila tha, to ab bol do
            pendingText?.let {
                speak(it)
                pendingText = null
            }
        } else {
            Log.e("VoiceSpeaker", "TTS Initialization Failed!")
        }
    }

    fun speak(text: String) {
        if (isReady) {
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "LisaaTTS")
        } else {
            // Jab tak ready nahi hota, text ko pending me rakho
            pendingText = text
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
