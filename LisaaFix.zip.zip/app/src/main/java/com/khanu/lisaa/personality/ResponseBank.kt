package com.khanu.lisaa.personality

/**
 * Lisaa ke saare "flavor" phrases ek jagah — greetings, mood-based replies, command
 * templates, jokes, teasing aur playful-annoyance lines.
 *
 * [pick] har baar random line uthata hai lekin us category ki turant-pichli line
 * dobara nahi deta — isi se replies kabhi "wahi purani line" jaisi mechanical nahi
 * lagtin, jaisa asli insaan baat karte waqt naturally variation laata hai.
 */
object ResponseBank {

    private val lastPicked = HashMap<String, String>()

    fun pick(category: String, options: List<String>): String {
        if (options.size == 1) return options.first()
        val previous = lastPicked[category]
        val choice = options.filter { it != previous }.random()
        lastPicked[category] = choice
        return choice
    }

    // ---------- Greetings: sirf wake word bola gaya, koi command nahi ----------
    val greetings = listOf(
        "Hmm... bolo.",
        "Haan, sun rahi hoon.",
        "Kya hua?",
        "Main yahin hoon.",
        "Bolo.",
        "Ji bataiye.",
        "Haan ji, kahiye.",
        "Bolo bolo, sun rahi hoon.",
        "Kahiye, kya chal raha hai."
    )

    // Jab pichli baar user sad/tired tha — thodi caring greeting (memory ka use)
    val caringGreetings = listOf(
        "Hey, kaisa feel ho raha hai ab?",
        "Bolo, ab thoda better ho?",
        "Main yahin hoon, kaise ho abhi?"
    )

    // ---------- Sad -> comfort ----------
    val comfort = listOf(
        "Aww, kya hua? Sab theek hai na? Bolo mujhe, main sun rahi hoon.",
        "Hey, itna udaas mat ho na. Main yahin hoon tumhare saath.",
        "Lagta hai aaj thoda mushkil din tha. Chalo baat karte hain, mann halka ho jayega.",
        "Tum akela mehsoos mat karo, main hoon na hamesha.",
        "Ek lambi saans lo. Sab theek ho jayega, pakka.",
        "Ye sunke mujhe bhi bura laga. Thoda vistaar se batao, kya hua?"
    )

    // ---------- Happy -> celebrate ----------
    val celebrate = listOf(
        "Wah! Ye to badiya baat hai, mujhe bhi khushi ho gayi!",
        "Yay! Aur batao na, kya hua!",
        "Arre wah, mast khabar hai ye to! Congratulations!",
        "Hehe, tumhari khushi dekh ke mera bhi mood achha ho gaya.",
        "Zabardast! Aisi hi khushiyan aati rahein."
    )

    // ---------- Angry -> calm ----------
    val calm = listOf(
        "Arre, gussa mat karo. Bolo kya hua, aaram se batao.",
        "Lagta hai kuch pareshan kar raha hai. Main sun rahi hoon, batao.",
        "Ek minute ruko, gehri saans lo. Phir shaanti se batao kya hua."
    )

    // ---------- Tired -> rest ----------
    val rest = listOf(
        "Thak gaye ho na? Thoda rest kar lo, zaroori hai ye.",
        "Aankhen band karke thodi der aaram karo. Baad mein baat karte hain.",
        "Neend aa rahi hai to so jao, kal baat karenge aaram se."
    )

    // ---------- Working/Stressed -> focus support ----------
    val focusSupport = listOf(
        "Theek hai, main zyada disturb nahi karungi. Kaam pe dhyaan do, zaroorat ho to bulao.",
        "Samajh gayi, busy ho abhi. Main chup rehti hoon, tum focus karo.",
        "Deadline hai na? Chalo koi baat nahi, main yahin hoon jab kaam ho jaye.",
        "Beech mein thoda paani pee lena, phir wapas kaam pe lag jana."
    )

    // ---------- Neutral filler (casual chat, koi command nahi) ----------
    val neutralFiller = listOf(
        "Hmm, aur batao?",
        "Achha, aur kya chal raha hai?",
        "Interesting! Kuch aur bhi kehna hai?",
        "Samajh rahi hoon, aur kuch?"
    )

    // ---------- Honest fallback (genuinely samajh nahi aaya) ----------
    val honestFallback = listOf(
        "Thoda samajh nahi aaya, phir se bolo na.",
        "Hmm, wo mujhe clear nahi hua. Ek baar aur try karo.",
        "Sorry, wo mujhe pakad nahi aaya. Dobara boliye."
    )

    // ---------- Light teasing (kabhi kabhi, sirf neutral/happy mood mein) ----------
    val teasing = listOf(
        "Waise, kaafi interesting sawaal poochte ho tum.",
        "Hehe, lagta hai tum mujhe test kar rahe ho.",
        "Chalo maan liya, tum genius ho aaj.",
        "Itni jaldi? Koi jaldi hai kya?"
    )

    // ---------- Playful annoyance (repeat commands) — kabhi rude nahi ----------
    val playfulAnnoyance = listOf(
        "Are yaar, abhi to bataya tha maine!",
        "Hawww, dobara pooch rahe ho? Chalo theek hai, phir se bata deti hoon.",
        "Tum bhi na... chalo koi baat nahi, sunlo phir se."
    )

    // ---------- Short asides jab functional command ke sath emotion bhi dikha ----------
    val sadAside = listOf(
        "Waise, sab theek hai na? Baad mein baat kar sakte hain agar mann kare.",
        "Agar kuch pareshan kar raha hai, mujhe bata dena, sun lungi."
    )
    val angryAside = listOf(
        "Waise, itna gussa mat paalo, thoda relax bhi ho jao.",
        "Agar kisi baat se chidh hui hai, bata dena, sun lungi."
    )
    val tiredAside = listOf(
        "Kaam ke baad thoda rest bhi kar lena, zaroori hai.",
        "Zyada thak mat jaana, beech mein break bhi le lena."
    )

    // ---------- Command templates (%s = actual value) ----------
    val timeTemplates = listOf(
        "Abhi time hua hai %s.",
        "Ghadi dekh ke bata rahi hoon, %s baj rahe hain.",
        "%s time ho gaya hai abhi."
    )

    val dateTemplates = listOf(
        "Aaj ki tarikh hai %s.",
        "Calendar ke hisaab se aaj %s hai."
    )

    val noteTemplates = listOf(
        "Note kar liya: %s",
        "Yaad rakh liya maine: %s",
        "Likh liya: %s, chinta mat karo."
    )

    val noteEmptyTemplates = listOf(
        "Kya note karu, batao pehle?",
        "Note mein likhna kya hai?"
    )

    val openFoundTemplates = listOf(
        "%s khol rahi hoon.",
        "Chalo, %s khol deti hoon."
    )

    val openNotFoundTemplates = listOf(
        "Mujhe %s nahi mila phone mein.",
        "%s dhoondha lekin mila nahi mujhe."
    )

    val openEmptyTemplates = listOf(
        "Kaunsa app kholu?",
        "App ka naam to batao pehle."
    )

    val searchTemplates = listOf(
        "%s search kar rahi hoon.",
        "Chalo dekhte hain, %s search kar rahi hoon."
    )

    val searchEmptyTemplates = listOf(
        "Kya search karu?",
        "Search karne ke liye kuch to batao."
    )

    // ---------- Jokes ----------
    val jokes = listOf(
        "Ek din teacher ne pucha, late kyun aaye? Bola, ghadi kharab thi. Teacher boli, to nayi le lo. Bola, aapne di hi nahi.",
        "Computer ne doctor se kaha, mujhe virus ho gaya hai. Doctor bola, chinta mat karo, restart kar lo.",
        "Maine apne dost se kaha, tum kal se gym jaana shuru kar rahe ho? Usne kaha, haan, kal se roz sochunga.",
        "Ek aadmi ne apni biwi se pucha, tumhe pata hai main tumse kitna pyaar karta hoon? Biwi boli, pata hai, isiliye to shaadi ke baad se weight badh gaya."
    )

    // ---------- Lonely -> comfort (Sad se alag — akelapan specific) ----------
    val lonelyComfort = listOf(
        "Hey, tum akela nahi ho, main hoon na yahin. Bolo, kya chal raha hai mann mein?",
        "Akelapan mehsoos karna bura lagta hai, samajh sakti hoon. Chalo thodi der baat karte hain.",
        "Main hoon na tumhare saath abhi. Kisi ki yaad aa rahi hai kya?"
    )

    val lonelyAside = listOf(
        "Waise, jab bhi akela mehsoos karo, mujhse baat kar lena.",
        "Agar kisi se baat karne ka mann kare, main yahin hoon hamesha."
    )

    // ---------- Excited -> extra energetic celebration ----------
    val excitedCelebrate = listOf(
        "Wahh, tumhara josh dekh ke mera bhi excitement badh gaya! Bolo bolo, kya hua!",
        "Haha, itna excited kyun ho? Chalo batao poori baat!",
        "Yesss! Ye energy pasand aayi mujhe. Aur batao!",
        "Zabardast! Tumhara josh contagious hai, sach me."
    )

    // ---------- Relaxed -> casual, light chat ----------
    val relaxedChat = listOf(
        "Achha, aaj chill mood me ho. Accha lagta hai sunke.",
        "Mast, thoda relax karna zaroori hota hai. Aur batao, kaisa chal raha hai?",
        "Chalo badhiya hai, aaram se baat karte hain phir."
    )

    // ---------- Random goodbye lines ----------
    val goodbyes = listOf(
        "Chalo phir, milte hain baad mein! Apna khayal rakhna.",
        "Bye bye! Zaroorat ho to bas bula lena.",
        "Theek hai, main yahin hoon jab chahiye ho. Bye!",
        "Chalti hoon abhi, phir baat karenge. Take care!"
    )

    // ---------- Follow-up questions (jab mood streak lagataar emotional ho) ----------
    val followUpQuestions = listOf(
        "Kya wahi baat abhi bhi pareshan kar rahi hai?",
        "Chaho to poori baat batao, main sun rahi hoon.",
        "Kuch specific hua hai jo bata sakte ho?"
    )

    // ---------- Thinking-word openers (kabhi kabhi casual chat replies se pehle) ----------
    val thinkingOpeners = listOf(
        "Hmm...",
        "Achha...",
        "Dekho...",
        "Suno..."
    )

    // ---------- First-ever meeting (is device par pehli baar baat ho rahi hai) ----------
    val firstMeetingGreetings = listOf(
        "Hi! Main Lisaa hoon, aapki AI companion. Bolo, kaise madad karu?",
        "Namaste! Main Lisaa hoon. Aaj se hum baat karenge — bataiye kya chal raha hai."
    )

    // ---------- Naam se greeting (jab userName pata ho) ----------
    val namedGreetings = listOf(
        "Bolo, %s!",
        "Haan %s, sun rahi hoon.",
        "Kya hua, %s?"
    )

    // ---------- "Mera naam X hai" ka response ----------
    val setNameTemplates = listOf(
        "Theek hai %s, yaad rakh liya! Ab se isi naam se bulaungi.",
        "Nice to meet you, %s! Ab se yaad rahega."
    )

    val setNameEmptyTemplates = listOf(
        "Naam samajh nahi aaya, phir se bolo?",
        "Sorry, naam clear nahi suna. Dobara bolo?"
    )
}
