package com.khanu.lisaa.command

import java.util.Locale

/**
 * Raw recognized text ko ek structured [Command] me todta hai.
 * Yahi keyword-matching approach jo pehle Service class ke andar seedha likha tha —
 * ab isse alag class me nikala gaya hai taaki:
 *  1. LisaaService thin controller rahe (sirf orchestration, koi parsing logic nahi).
 *  2. Parsing logic testable ho (koi Android dependency nahi is class me).
 *  3. Command aur mood detection dono raw text par independently chal sakein.
 */
object CommandInterpreter {

    fun parse(rawCommand: String): Command {
        val c = rawCommand.lowercase(Locale.getDefault()).trim()

        return when {
            c.contains("mera naam") -> {
                val name = c.substringAfter("mera naam").trim().removeSuffix("hai").trim()
                Command.SetName(name)
            }

            c.contains("my name is") -> {
                val name = c.substringAfter("my name is").trim()
                Command.SetName(name)
            }

            c.contains("time") || c.contains("samay") -> Command.Time

            c.contains("date") || c.contains("tarikh") -> Command.Date

            c.contains("khol") || c.contains("open") -> {
                val appName = c.replace("khol", "").replace("open", "").trim()
                Command.OpenApp(appName)
            }

            c.contains("search") || c.contains("khoj") -> {
                val query = c.replace("search", "").replace("khoj", "").trim()
                Command.Search(query)
            }

            c.contains("note") || c.contains("yaad rakho") -> {
                val note = c.replace("note", "").replace("yaad rakho", "").trim()
                Command.Note(note)
            }

            c.contains("joke") || c.contains("chutkula") -> Command.Joke

            c.contains("bye") || c.contains("alvida") || c.contains("good night") ||
                c.contains("phir milenge") -> Command.Goodbye

            else -> Command.Unknown(rawCommand)
        }
    }
}
