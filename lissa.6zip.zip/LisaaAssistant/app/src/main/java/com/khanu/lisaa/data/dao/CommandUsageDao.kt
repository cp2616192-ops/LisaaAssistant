package com.khanu.lisaa.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.khanu.lisaa.data.entity.CommandUsageEntity

@Dao
interface CommandUsageDao {

    @Query("SELECT * FROM command_usage WHERE actionKey = :key LIMIT 1")
    suspend fun get(key: String): CommandUsageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: CommandUsageEntity)

    @Query("SELECT * FROM command_usage ORDER BY count DESC LIMIT :limit")
    suspend fun getTopUsed(limit: Int): List<CommandUsageEntity>
}
