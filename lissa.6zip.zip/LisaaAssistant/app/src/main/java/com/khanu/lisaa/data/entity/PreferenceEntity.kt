package com.khanu.lisaa.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Generic key-value store for user preferences / behavioral state — jaise focus
 * mode ka timestamp — taaki app ya service restart hone ke baad bhi Lisaa ko
 * yaad rahe. Extensible design: naye preferences (settings) add karne ke liye
 * koi schema migration nahi chahiye, bas ek nayi key use karo.
 */
@Entity(tableName = "preferences")
data class PreferenceEntity(
    @PrimaryKey val prefKey: String,
    val prefValue: String
)
