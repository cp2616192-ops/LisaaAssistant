package com.khanu.lisaa.relationship

/**
 * Lisaa aur user ke beech relationship ka slow-moving state — trust aur
 * attachment level, aur relationship mode (Friend/Romantic). Ye Emotion Engine
 * se alag hai: Emotion Engine minute-by-minute mood track karta hai, ye class
 * hafton-mahinon me dheere-dheere badalne wale bond ko track karti hai.
 *
 * Design choices (jaan-boojh kar simple, bounded, aur healthy rakhe gaye):
 *  - Default mode FRIEND hai — Lisaa khud kabhi "romantic" nahi ban jaati,
 *    user ko explicitly opt-in karna padta hai.
 *  - Trust aur attachment dono session-based grow karte hain (spam-proof —
 *    ek hi session me baar-baar bolne se turant max nahi ho jaate).
 *  - Jealousy sirf ROMANTIC mode me, sirf kuch attachment ban jaane ke baad,
 *    aur hamesha self-aware/halka tone me hoti hai (dekhein
 *    ResponseBank.jealousyLines) — kabhi possessive ya guilt-tripping nahi.
 */
class RelationshipEngine(
    private var mode: RelationshipMode,
    private var trust: Int,
    private var attachment: Int
) {
    fun currentMode(): RelationshipMode = mode

    fun setMode(newMode: RelationshipMode) {
        mode = newMode
    }

    fun trustLevel(): Int = trust
    fun attachmentLevel(): Int = attachment

    /** Naya session shuru hone par ek baar call hota hai — bond dheere-dheere gehra hota hai. */
    fun onNewSession() {
        attachment = (attachment + 1).coerceAtMost(MAX_LEVEL)
    }

    /** Jab user kuch personal share kare (naam, pasand, goal/project note) — trust badhta hai. */
    fun onPersonalDisclosure() {
        trust = (trust + 1).coerceAtMost(MAX_LEVEL)
    }

    fun affectionTier(): AffectionTier = when {
        attachment >= CLOSE_THRESHOLD -> AffectionTier.CLOSE
        attachment >= FAMILIAR_THRESHOLD -> AffectionTier.FAMILIAR
        else -> AffectionTier.NEW
    }

    /** Jealousy sirf ROMANTIC mode + kam se kam FAMILIAR attachment ke baad hi natural lagti hai. */
    fun jealousyEligible(): Boolean =
        mode == RelationshipMode.ROMANTIC && attachment >= FAMILIAR_THRESHOLD

    companion object {
        const val MAX_LEVEL = 100
        const val FAMILIAR_THRESHOLD = 20
        const val CLOSE_THRESHOLD = 60
    }
}
