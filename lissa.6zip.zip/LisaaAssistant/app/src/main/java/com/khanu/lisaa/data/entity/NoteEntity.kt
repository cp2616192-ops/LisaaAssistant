package com.khanu.lisaa.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * "Note karo" / "yaad rakho" commands se bane notes.
 * Pehle ye sirf RAM (mutableListOf) me the aur service restart hote hi gayab ho
 * jaate the — ek real bug tha. Ab Room me persist hote hain.
 *
 * Module 3: `category` field add hui — LisaaBrain note ke text me "goal"/"project"
 * jaise keywords dekh kar khud category set karta hai (goal/project/general),
 * taaki "remember goals and projects" requirement bhi isi table se poori ho,
 * bina alag tables banaye.
 */
@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val category: String = "general",
    val timestamp: Long = System.currentTimeMillis()
)
