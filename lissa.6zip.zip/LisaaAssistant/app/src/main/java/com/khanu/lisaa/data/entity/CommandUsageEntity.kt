package com.khanu.lisaa.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Kaunsa command/app kitni baar use hua — "frequently used commands" aur
 * "favourite apps" dono isi table se nikalte hain. Keys jaise "open:whatsapp"
 * apps track karti hain; "time"/"joke"/"note"/"search" jaisi keys general
 * command usage track karti hain — ek hi table, do use-cases, koi duplication nahi.
 */
@Entity(tableName = "command_usage")
data class CommandUsageEntity(
    @PrimaryKey val actionKey: String,
    val count: Int,
    val lastUsed: Long
)
