package com.khanu.lisaa.ui

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * App-wide (same-process) shared state — LisaaService (writer) aur MainActivity
 * (reader) dono isi se baat karte hain taaki orb animation live update ho.
 *
 * Service background me chal sakti hai jab Activity nahi hai (foreground
 * service) — is holder ka koi Activity/Lifecycle dependency nahi hai, isliye
 * ye dono taraf se safe hai. MainActivity is StateFlow ko collect karta hai
 * sirf jab tak wo khud visible hai (repeatOnLifecycle ke through) — battery
 * ke liye zaroori.
 */
object AssistantStateHolder {
    private val _state = MutableStateFlow(AssistantState.IDLE)
    val state: StateFlow<AssistantState> = _state

    fun setState(newState: AssistantState) {
        _state.value = newState
    }
}
