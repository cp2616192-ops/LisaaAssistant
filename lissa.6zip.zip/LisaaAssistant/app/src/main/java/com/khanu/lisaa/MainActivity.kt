package com.khanu.lisaa

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.khanu.lisaa.ui.LisaaOrbView
import com.khanu.lisaa.viewmodel.LisaaViewModel
import kotlinx.coroutines.launch

/**
 * App ka entry screen — pure View layer (MVVM). Koi business logic yahan nahi
 * hai; Service start/stop, status text, aur memory count sab [LisaaViewModel]
 * se aate hain. Activity ab kabhi seedha `Intent(this, LisaaService::class.java)`
 * nahi banata — Module 4 se ye responsibility poori tarah ViewModel me hai.
 *
 * Permission handling aur battery-optimization exemption yahin rehte hain
 * kyunki Android inhe sirf Activity context se hi maangne deta hai (ye
 * Android-platform constraint hai, business logic nahi).
 */
class MainActivity : AppCompatActivity() {

    private val requestCode = 100
    private val viewModel: LisaaViewModel by viewModels()

    private fun requiredPermissions(): Array<String> {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        return perms.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.statusText)
        val memoryText = findViewById<TextView>(R.id.memoryText)
        val startButton = findViewById<Button>(R.id.startButton)
        val stopButton = findViewById<Button>(R.id.stopButton)
        val orbView = findViewById<LisaaOrbView>(R.id.orbView)

        // Teeno StateFlow ek sath collect — orb animation, status text, aur
        // reactive memory count — sirf jab tak Activity STARTED hai (battery-friendly).
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { viewModel.assistantState.collect { orbView.setState(it) } }
                launch { viewModel.statusText.collect { statusText.text = it } }
                launch {
                    viewModel.memoryCount.collect { count ->
                        memoryText.text = if (count > 0) "$count baatein yaad hain" else ""
                    }
                }
            }
        }

        startButton.setOnClickListener {
            if (hasPermissions()) {
                viewModel.startLisaa()
                askBatteryOptimizationExemption()
            } else {
                ActivityCompat.requestPermissions(this, requiredPermissions(), requestCode)
            }
        }

        stopButton.setOnClickListener {
            viewModel.stopLisaa()
        }
    }

    private fun hasPermissions(): Boolean =
        requiredPermissions().all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    // Android battery-saving Doze mode background service ko rok sakta hai.
    // Ye exemption maangta hai taaki Lisaa reliably chalti rahe.
    private fun askBatteryOptimizationExemption() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } catch (e: Exception) {
                // Device isse support nahi karta to ignore kar do
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            viewModel.startLisaa()
            askBatteryOptimizationExemption()
        }
    }
}
