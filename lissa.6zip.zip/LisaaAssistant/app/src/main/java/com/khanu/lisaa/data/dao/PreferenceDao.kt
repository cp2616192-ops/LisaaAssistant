package com.khanu.lisaa.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.khanu.lisaa.data.entity.PreferenceEntity

@Dao
interface PreferenceDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(preference: PreferenceEntity)

    @Query("SELECT prefValue FROM preferences WHERE prefKey = :key LIMIT 1")
    suspend fun get(key: String): String?
}
