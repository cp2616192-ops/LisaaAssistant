package com.khanu.lisaa.viewmodel

import android.app.Application
import android.content.Intent
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.khanu.lisaa.data.repository.MemoryRepository
import com.khanu.lisaa.service.LisaaService
import com.khanu.lisaa.ui.AssistantState
import com.khanu.lisaa.ui.AssistantStateHolder
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

/**
 * MainActivity (View) sirf isse baat karta hai — koi business logic Activity mein
 * nahi hai. Module 4 se pehle Activity seedha `Intent(this, LisaaService::class.java)`
 * bana kar `startForegroundService()`/`stopService()` call karta tha; ab wo
 * responsibility yahan encapsulated hai — MVVM completion ka core piece.
 *
 * - Repository: [MemoryRepository] ke through Room se baat hoti hai.
 * - Flow: [memoryCount] reactive hai — Room me naya conversation save hote hi
 *   khud-ba-khud update hota hai, koi manual refresh nahi chahiye.
 * - Service state: [assistantState] Service (jo state ka "writer" hai) se
 *   [AssistantStateHolder] ke through aata hai, ViewModel ke through re-expose hota hai
 *   taaki Activity kabhi seedha singleton ko na chhue.
 *
 * Dependency Injection note: is app ke size par Hilt/Koin jaisa DI framework
 * jodna extra complexity add karta hai bina kisi real benefit ke — manual
 * constructor injection (jaisa LisaaBrain/MemoryRepository me hai) already
 * testable aur saaf hai. Isliye jaan-boojh kar DI framework nahi joda gaya.
 */
class LisaaViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = MemoryRepository(application)

    private val _statusText = MutableStateFlow("Lisaa abhi so rahi hai")
    val statusText: StateFlow<String> = _statusText

    /** Orb animation isi se driven hoti hai. */
    val assistantState: StateFlow<AssistantState> = AssistantStateHolder.state

    /** Reactive — Room me naya conversation save hote hi ye khud-ba-khud update hota hai (Flow). */
    val memoryCount: StateFlow<Int> = repository.observeConversationCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun startLisaa() {
        val context = getApplication<Application>()
        val serviceIntent = Intent(context, LisaaService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
        _statusText.value = "Lisaa jaag gayi hai.\n\"Hey Lisaa\" bol kar baat shuru karein."
    }

    fun stopLisaa() {
        val context = getApplication<Application>()
        context.stopService(Intent(context, LisaaService::class.java))
        _statusText.value = "Lisaa so gayi, phir milenge."
    }
}
