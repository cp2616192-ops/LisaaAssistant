package com.khanu.lisaa.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.khanu.lisaa.data.entity.NoteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {

    @Insert
    suspend fun insert(note: NoteEntity)

    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    suspend fun getAll(): List<NoteEntity>

    /** Reactive — goals/projects/notes screen (future) isse live updates paayega. */
    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<NoteEntity>>
}
