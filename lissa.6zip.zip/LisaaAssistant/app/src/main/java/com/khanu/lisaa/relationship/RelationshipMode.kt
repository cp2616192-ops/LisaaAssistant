package com.khanu.lisaa.relationship

/**
 * Lisaa kaise behave kare — pure platonic dosti, ya thoda zyada affectionate
 * companion. Default hamesha FRIEND hai; ROMANTIC sirf user ke explicit
 * opt-in se activate hoti hai ("romantic mode" bol kar) — Lisaa khud kabhi
 * presume nahi karti.
 */
enum class RelationshipMode {
    FRIEND,
    ROMANTIC
}
