package com.khanu.lisaa.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Ek conversation turn ka record — Lisaa ki long-term memory.
 * Har baar jab user kuch bolta hai aur Lisaa reply karti hai, ek row yahan
 * permanently save hoti hai device ke local Room database me. Koi cloud/internet
 * involved nahi — sab offline, phone par hi.
 */
@Entity(tableName = "conversation_entries")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userText: String,
    val lisaaReply: String,
    val mood: String,
    val timestamp: Long = System.currentTimeMillis()
)
