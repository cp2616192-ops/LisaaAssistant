package com.khanu.lisaa.emotion

import com.khanu.lisaa.personality.Mood

/**
 * Lisaa ka apna emotional state — [com.khanu.lisaa.personality.MoodDetector]
 * (jo USER ka mood detect karta hai) se bilkul alag concept hai. Ye class
 * Lisaa ki khud ki "warmth" track karti hai: ek bounded 0-100 score jo
 * interactions ke saath dheere-dheere badalta/ghatata hai, kabhi turant jump
 * nahi karta — taaki emotional state "changes over time" jaisa feel ho, ek
 * instant mood-swing jaisa nahi.
 *
 * Safety-conscious design: warmth kabhi [MIN_WARMTH_FLOOR] se neeche nahi
 * girti — Lisaa lambe gap ke baad thodi si "miss kar rahi thi" jaisi lag
 * sakti hai, lekin kabhi genuinely thandi, sulking, ya user ko punish karne
 * jaisa behavior nahi karti. Wo hamesha fundamentally caring rehti hai.
 */
class EmotionEngine(private var warmth: Int) {

    fun currentWarmth(): Int = warmth

    /** Har interaction ke baad user ke mood se halka sa influenced hoti hai (mirroring, lekin bounded). */
    fun reactTo(userMood: Mood) {
        val delta = when (userMood) {
            Mood.HAPPY, Mood.EXCITED -> 3
            Mood.RELAXED -> 1
            Mood.SAD, Mood.LONELY, Mood.ANGRY -> -1 // thodi caring-concern, khud "gussa/sad" nahi ho jaati
            Mood.TIRED, Mood.WORKING, Mood.NEUTRAL -> 0
        }
        warmth = (warmth + delta).coerceIn(0, 100)
    }

    /** Lambe gap ke baad thodi si warmth kam hoti hai — "miss kar rahi thi" jaisa natural feel, kabhi punishing nahi. */
    fun applyInactivityDecay(hoursSinceLastSeen: Long) {
        if (hoursSinceLastSeen >= LONG_GAP_HOURS) {
            warmth = (warmth - 5).coerceAtLeast(MIN_WARMTH_FLOOR)
        }
    }

    /** Lisaa ke apne current warmth ko ek Mood tone me convert karta hai — greeting ke TTS pitch/rate ke liye. */
    fun toneMood(): Mood = when {
        warmth >= 70 -> Mood.HAPPY
        warmth <= 30 -> Mood.LONELY
        else -> Mood.RELAXED
    }

    companion object {
        const val LONG_GAP_HOURS = 12L
        const val MIN_WARMTH_FLOOR = 25
    }
}
