package com.khanu.lisaa.brain

import com.khanu.lisaa.personality.Mood

/** LisaaBrain ka final output — Service ko sirf itna chahiye: kya bolna hai, kis mood me. */
data class BrainResult(
    val replyText: String,
    val mood: Mood
)
