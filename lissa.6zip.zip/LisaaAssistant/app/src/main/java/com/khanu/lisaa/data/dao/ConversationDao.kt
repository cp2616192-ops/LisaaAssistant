package com.khanu.lisaa.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.khanu.lisaa.data.entity.ConversationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {

    @Insert
    suspend fun insert(entry: ConversationEntity)

    @Query("SELECT * FROM conversation_entries ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<ConversationEntity>

    @Query("SELECT * FROM conversation_entries ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLast(): ConversationEntity?

    @Query("SELECT COUNT(*) FROM conversation_entries")
    suspend fun count(): Int

    /** Reactive — Room khud emit karta hai jab bhi table change hoti hai. ViewModel isse UI me live memory-count dikhane ke liye collect karta hai. */
    @Query("SELECT COUNT(*) FROM conversation_entries")
    fun observeCount(): Flow<Int>

    // Database ko halka rakhne ke liye sirf latest N entries rakhte hain, purani hata dete hain
    @Query(
        "DELETE FROM conversation_entries WHERE id NOT IN " +
            "(SELECT id FROM conversation_entries ORDER BY timestamp DESC LIMIT :keep)"
    )
    suspend fun trimTo(keep: Int)
}
