package com.khanu.lisaa.voice

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.util.Constants
import java.util.Locale

class VoiceSpeaker(
    private val context: Context,
    private val onReadyToListenAgain: () -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false
    private var pendingSpeech: Pair<String, Mood>? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { /* no-op */ }

    init {
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val res = tts?.setLanguage(Locale("hi", "IN"))
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
            selectFemaleVoiceIfAvailable()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    abandonAudioFocus()
                    handler.post { onReadyToListenAgain() }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    abandonAudioFocus()
                    handler.post { onReadyToListenAgain() }
                }
            })
            ready = true

            // Agar initialization complete hone se pehle koi speak command aayi thi
            pendingSpeech?.let { (text, mood) ->
                speakNow(text, mood)
                pendingSpeech = null
            }
        } else {
            handler.post { onReadyToListenAgain() }
        }
    }

    private fun selectFemaleVoiceIfAvailable() {
        val engine = tts ?: return
        val candidate: Voice? = runCatching {
            engine.voices?.firstOrNull {
                it.locale.language == "hi" && it.name.lowercase(Locale.US).contains("female")
            } ?: engine.voices?.firstOrNull {
                it.locale.language == "en" && it.name.lowercase(Locale.US).contains("female")
            }
        }.getOrNull()
        candidate?.let { engine.voice = it }
    }

    fun speak(text: String, mood: Mood) {
        if (text.isBlank()) {
            onReadyToListenAgain()
            return
        }

        if (!ready) {
            pendingSpeech = text to mood
            return
        }

        speakNow(text, mood)
    }

    private fun speakNow(text: String, mood: Mood) {
        requestAudioFocus()
        applyMoodTone(mood)

        val utteranceId = "${Constants.TTS_UTTERANCE_ID}_${System.nanoTime()}"
        val maxLen = TextToSpeech.getMaxSpeechInputLength()
        val safeText = if (text.length > maxLen) text.take((maxLen - 1).coerceAtLeast(0)) else text

        // Direct QUEUE_FLUSH ke saath clear speak command - taaki koi silent gap speech ko block na kare
        val result = tts?.speak(safeText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        
        if (result == TextToSpeech.ERROR) {
            abandonAudioFocus()
            onReadyToListenAgain()
        }
    }

    private fun applyMoodTone(mood: Mood) {
        val (pitch, rate) = when (mood) {
            Mood.SAD, Mood.LONELY, Mood.TIRED -> 0.95f to 0.90f
            Mood.HAPPY -> 1.08f to 1.05f
            Mood.EXCITED -> 1.12f to 1.10f
            Mood.ANGRY -> 0.98f to 0.95f
            Mood.WORKING -> 1.0f to 1.0f
            Mood.RELAXED -> 1.0f to 0.95f
            Mood.NEUTRAL -> 1.02f to 1.0f
        }
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
    }

    private fun requestAudioFocus() {
        @Suppress("DEPRECATION")
        audioManager?.requestAudioFocus(
            focusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        )
    }

    private fun abandonAudioFocus() {
        @Suppress("DEPRECATION")
        audioManager?.abandonAudioFocus(focusChangeListener)
    }

    fun shutdown() {
        abandonAudioFocus()
        tts?.stop()
        tts?.shutdown()
        handler.removeCallbacksAndMessages(null)
    }
}
