package com.khanu.lisaa.brain

import com.khanu.lisaa.data.repository.MemoryRepository
import com.khanu.lisaa.personality.Mood
import java.util.Locale

class LisaaBrain(
    private val repository: MemoryRepository,
    private val appOpener: (String) -> Boolean,
    private val searcher: (String) -> Unit
) {

    suspend fun loadContext() {
        // Initialization if needed
    }

    suspend fun handleUtterance(userInput: String): BrainResult? {
        val cleanInput = userInput.trim().lowercase(Locale.getDefault())

        // Background Wake-Word Trigger: Jab tak "lisaa" na bole, response mat do
        if (!cleanInput.contains("lisaa") && !cleanInput.contains("lisa")) {
            return null // Ignore everything until "Lisaa" is said
        }

        // Clean user prompt (remove wake word from actual message)
        val prompt = cleanInput.replace("lisaa", "").replace("lisa", "").trim()

        if (prompt.isEmpty()) {
            return BrainResult("Haanji, main sun rahi hoon! Batiye kya kaam hai?", Mood.HAPPY)
        }

        // App Launch Intent Check
        if (prompt.contains("open") || prompt.contains("kholo")) {
            val appName = prompt.replace("open", "").replace("kholo", "").trim()
            val opened = appOpener(appName)
            return if (opened) {
                BrainResult("$appName khol rahi hoon...", Mood.HAPPY)
            } else {
                BrainResult("Aapke phone me $appName nahi mila.", Mood.SAD)
            }
        }

        // Google Search Check
        if (prompt.contains("search") || prompt.contains("dhoondo")) {
            val query = prompt.replace("search", "").replace("dhoondo", "").trim()
            searcher(query)
            return BrainResult("$query Google par search kar rahi hoon.", Mood.WORKING)
        }

        // Default Conversation Response
        return BrainResult("Maine aapki baat sun li: $prompt", Mood.NEUTRAL)
    }
}
