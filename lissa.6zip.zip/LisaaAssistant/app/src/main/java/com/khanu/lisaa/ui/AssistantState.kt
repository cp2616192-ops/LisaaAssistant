package com.khanu.lisaa.ui

/** Lisaa ka current visual/interaction state — orb animation isi se driven hoti hai. */
enum class AssistantState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING
}
