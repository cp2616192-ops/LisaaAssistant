package com.khanu.lisaa.personality

import com.khanu.lisaa.relationship.AffectionTier
import com.khanu.lisaa.relationship.RelationshipMode

/**
 * Greeting banane ke liye zaroori saara context — ek jagah bundle kiya gaya
 * hai taaki PersonalityEngine.greeting() ka parameter list badhta hi na rahe
 * jaise naye engines (relationship, emotion) add hote hain.
 */
data class GreetingContext(
    val recentMood: Mood?,
    val userName: String?,
    val isFirstMeeting: Boolean,
    val isLongAbsence: Boolean,
    val relationshipMode: RelationshipMode,
    val affectionTier: AffectionTier
)
