package com.khanu.lisaa.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.khanu.lisaa.brain.BrainResult
import com.khanu.lisaa.brain.LisaaBrain
import com.khanu.lisaa.data.repository.MemoryRepository
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.ui.AssistantState
import com.khanu.lisaa.ui.AssistantStateHolder
import com.khanu.lisaa.util.Constants
import com.khanu.lisaa.voice.VoiceRecognizer
import com.khanu.lisaa.voice.VoiceSpeaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

class LisaaService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var repository: MemoryRepository
    private lateinit var brain: LisaaBrain
    private lateinit var recognizer: VoiceRecognizer
    private lateinit var speaker: VoiceSpeaker

    private var vibrator: Vibrator? = null
    private var toneGenerator: ToneGenerator? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()

        repository = MemoryRepository(applicationContext)
        brain = LisaaBrain(
            repository = repository,
            appOpener = ::launchApp,
            searcher = ::launchSearch
        )
        vibrator = resolveVibrator()
        toneGenerator = runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70) }.getOrNull()

        speaker = VoiceSpeaker(applicationContext) { onSpeakingFinished() }
        recognizer = VoiceRecognizer(applicationContext, ::onTextRecognized)

        serviceScope.launch {
            brain.loadContext()
            beginListening()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_ID,
                "Lisaa Assistant",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Lisaa Background Active")
            .setContentText("Aap 'Lisaa' bolkar ise activate kar sakte hain...")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(Constants.NOTIFICATION_ID, notification)
    }

    private fun resolveVibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as? Vibrator
        }

    private fun beginListening() {
        AssistantStateHolder.setState(AssistantState.LISTENING)
        recognizer.startListening()
    }

    private fun onTextRecognized(text: String) {
        if (text.isBlank()) {
            beginListening()
            return
        }

        serviceScope.launch {
            val result = brain.handleUtterance(text)
            
            // Wake word "Lisaa" hone par hi response aur beep chalegi
            if (result != null) {
                playActivationCue()
                AssistantStateHolder.setState(AssistantState.THINKING)
                speak(result)
            } else {
                beginListening() // Background me bina aawaz kiye continuous listening
            }
        }
    }

    private fun speak(result: BrainResult) {
        AssistantStateHolder.setState(AssistantState.SPEAKING)
        speaker.speak(result.replyText, result.mood)
    }

    private fun onSpeakingFinished() {
        beginListening()
    }

    private fun playActivationCue() {
        vibrator?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                it.vibrate(60)
            }
        }
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
    }

    private fun launchApp(appName: String): Boolean {
        @Suppress("DEPRECATION")
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull {
            packageManager.getApplicationLabel(it).toString()
                .lowercase(Locale.getDefault()).contains(appName)
        }
        val launchIntent = match?.let { packageManager.getLaunchIntentForPackage(it.packageName) }
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    private fun launchSearch(query: String) {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    override fun onDestroy() {
        recognizer.destroy()
        speaker.shutdown()
        toneGenerator?.release()
        AssistantStateHolder.setState(AssistantState.IDLE)
        serviceScope.cancel()
        super.onDestroy()
    }
}
