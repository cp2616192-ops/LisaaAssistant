package com.khanu.lisaa.personality

/**
 * Lisaa jo moods user ki baaton se pehchan sakti hai.
 * Module 3 me STRESSED ko WORKING naam diya gaya (matlab wahi hai), aur EXCITED,
 * LONELY, RELAXED naye add hue — taaki emotional range zyada real lage.
 */
enum class Mood {
    HAPPY,
    EXCITED,
    SAD,
    LONELY,
    ANGRY,
    TIRED,
    WORKING,
    RELAXED,
    NEUTRAL
}
