package com.khanu.lisaa.util

/**
 * App-wide constants: wake words, notification/channel ids, timing values.
 * Rakhne se ek hi jagah maintain karna aasan hai aur values kahin duplicate nahi hoti.
 */
object Constants {

    // "lisa" aur "lisaa" dono spelling rakhi hain kyunki Android ka speech recognizer
    // kabhi kabhi double 'a' ko single sun leta hai — isse wake word miss nahi hota.
    val WAKE_WORDS = listOf(
        "hey lisaa", "hey lisa",
        "lisaa", "lisa",
        "ok lisaa", "ok lisa"
    )

    const val NOTIFICATION_CHANNEL_ID = "lisaa_channel"
    const val NOTIFICATION_ID = 1
    const val TTS_UTTERANCE_ID = "lisaa_utterance"

    // Isi window ke andar wahi command dobara bola jaaye to "playful annoyance" trigger hoti hai
    const val REPEAT_COMMAND_WINDOW_MS = 15_000L

    // Stressed/working mood detect hone ke baad itni der Lisaa kam chatpati rehti hai (focus mode)
    const val FOCUS_MODE_DURATION_MS = 10 * 60_000L

    // Bolne se pehle ek chhota, random "sochne" jaisa pause — TTS turant robotic na lage
    const val THINKING_DELAY_MIN_MS = 400L
    const val THINKING_DELAY_MAX_MS = 1100L

    // Long-term memory ko halka rakhne ke liye sirf itni recent entries store karte hain
    const val MAX_MEMORY_ENTRIES = 200

    // Bolna shuru hone se theek pehle ek chhoti si "breathing" silence — mood ke
    // hisaab se thodi lambi ya chhoti (Module 4 voice-quality improvement)
    const val BREATH_PAUSE_MIN_MS = 100L
    const val BREATH_PAUSE_MAX_MS = 260L
}
