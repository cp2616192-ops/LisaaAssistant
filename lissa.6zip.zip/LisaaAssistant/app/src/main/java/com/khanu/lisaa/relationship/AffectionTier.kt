package com.khanu.lisaa.relationship

/**
 * Attachment level ke hisaab se relationship kitni "familiar" feel karti hai.
 * Sirf ROMANTIC mode ki phrasing warm karne ke liye use hoti hai — FRIEND mode
 * hamesha consistent rehta hai chahe tier kuch bhi ho, taaki wo mode kabhi
 * achanak "over-attached" na lage.
 */
enum class AffectionTier {
    NEW,
    FAMILIAR,
    CLOSE
}
