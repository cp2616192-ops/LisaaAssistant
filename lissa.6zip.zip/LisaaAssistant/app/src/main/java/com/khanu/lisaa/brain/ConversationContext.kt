package com.khanu.lisaa.brain

import com.khanu.lisaa.personality.Mood

/**
 * Current conversation ka short-term context — Lisaa "abhi kya chal raha hai"
 * yaad rakhti hai isi se: pichla mood, kitni baar wahi mood laga (streak —
 * taaki lagataar sad/lonely/angry mood par thodi zyada empathy dikhaye), aur
 * last command ka text/time (repeat-command detection ke liye).
 *
 * Ye class khud persist nahi hoti (session-scoped, in-memory) — sirf
 * focusModeUntil aur last mood hi long-term store hote hain, MemoryRepository
 * ke through (Room), aur session start par [LisaaBrain.loadContext] se wapas
 * yahan load ho jaate hain.
 */
class ConversationContext {
    var recentMood: Mood? = null
        private set

    var moodStreak: Int = 0
        private set

    var focusModeUntil: Long = 0L

    var lastCommandText: String? = null
    var lastCommandTime: Long = 0L

    /** User ne "mera naam X hai" bola ho to yahan store hota hai — Room preferences se load/save hota hai. */
    var userName: String? = null

    /** True sirf pehli-hi baar jab is device par Lisaa se kabhi baat na hui ho — special welcome ke liye. */
    var isFirstEverSession: Boolean = false

    /** Pichli baar (kisi bhi session me) aakhri interaction kab hua tha — long-absence reunion detect karne ke liye. */
    var lastSeenAt: Long = 0L

    /** Naya mood record karta hai aur agar pichle jaisa hi hai to streak badhata hai. */
    fun updateMood(newMood: Mood) {
        moodStreak = if (newMood == recentMood) moodStreak + 1 else 1
        recentMood = newMood
    }
}
