package com.khanu.lisaa.ui

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

/**
 * Lisaa ka animated "orb" — Antique Gold glow jo state ke hisaab se pulse karta
 * hai:
 *  - IDLE: dheema, halka pulse
 *  - LISTENING: brighter glow, medium-speed pulse
 *  - THINKING: chhote-chhote tez pulses (soch rahi hai jaisa)
 *  - SPEAKING: expanding wave rings
 *
 * Module 4: do cheezein add hui —
 *  1. Do offset "wave" rings (0.5 phase door) — ek akela ring ki jagah fuller,
 *     zyada organic wave-jaisa effect.
 *  2. Smooth color transitions — state badalne par color turant jump nahi karta,
 *     ArgbEvaluator se 300ms me crossfade hota hai.
 *
 * Pure Canvas-based hai — koi external animation library (Lottie etc.) nahi
 * chahiye, isliye APK size aur dependency surface dono chhote rehte hain.
 *
 * Scope note: ye animation MainActivity foreground me hone par hi dikhti hai.
 * System-wide overlay (jo dusre apps ke upar bhi dikhe) ke liye SYSTEM_ALERT_WINDOW
 * special permission aur ek alag overlay-window service chahiye hogi — scope se
 * bahar hai, future module ke liye chhoda gaya hai.
 */
class LisaaOrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var state: AssistantState = AssistantState.IDLE
    private var pulseFraction = 0f

    private var displayedColor: Int = colorFor(AssistantState.IDLE)
    private var colorAnimator: ValueAnimator? = null
    private val argbEvaluator = ArgbEvaluator()

    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }

    private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1400
        repeatCount = ValueAnimator.INFINITE
        repeatMode = ValueAnimator.RESTART
        interpolator = LinearInterpolator()
        addUpdateListener {
            pulseFraction = it.animatedValue as Float
            invalidate()
        }
    }

    init {
        pulseAnimator.start()
    }

    /** Service/ViewModel isse call karta hai jab Lisaa ka state badalta hai. */
    fun setState(newState: AssistantState) {
        if (state == newState) return
        state = newState
        pulseAnimator.duration = when (newState) {
            AssistantState.IDLE -> 2600L
            AssistantState.LISTENING -> 1400L
            AssistantState.THINKING -> 700L
            AssistantState.SPEAKING -> 1000L
        }
        animateColorTo(colorFor(newState))
    }

    /** Color ko turant badalne ke bajaye 300ms me smoothly crossfade karta hai. */
    private fun animateColorTo(targetColor: Int) {
        colorAnimator?.cancel()
        colorAnimator = ValueAnimator.ofObject(argbEvaluator, displayedColor, targetColor).apply {
            duration = 300
            addUpdateListener {
                displayedColor = it.animatedValue as Int
                invalidate()
            }
            start()
        }
    }

    private fun colorFor(s: AssistantState): Int = when (s) {
        AssistantState.IDLE -> Color.parseColor("#8B7500")
        AssistantState.LISTENING -> Color.parseColor("#D4AF37")
        AssistantState.THINKING -> Color.parseColor("#F2D57E")
        AssistantState.SPEAKING -> Color.parseColor("#FFE9A8")
    }

    @SuppressLint("DrawAllocation")
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val baseRadius = width.coerceAtMost(height) / 5f

        // Do offset wave rings — ek dusre se 0.5 phase door — taaki ek akela ring
        // ki jagah ek fuller, zyada organic "wave" jaisa effect bane.
        drawWaveRing(canvas, cx, cy, baseRadius, pulseFraction)
        drawWaveRing(canvas, cx, cy, baseRadius, (pulseFraction + 0.5f) % 1f)

        // Glowing core
        corePaint.shader = RadialGradient(
            cx, cy, baseRadius.coerceAtLeast(1f),
            displayedColor, Color.parseColor("#111111"),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, baseRadius, corePaint)
    }

    private fun drawWaveRing(canvas: Canvas, cx: Float, cy: Float, baseRadius: Float, fraction: Float) {
        val ringRadius = baseRadius + (baseRadius * 1.6f * fraction)
        ringPaint.color = displayedColor
        ringPaint.alpha = ((1f - fraction) * 200).toInt().coerceIn(0, 255)
        canvas.drawCircle(cx, cy, ringRadius, ringPaint)
    }

    override fun onDetachedFromWindow() {
        pulseAnimator.cancel()
        colorAnimator?.cancel()
        super.onDetachedFromWindow()
    }
}
