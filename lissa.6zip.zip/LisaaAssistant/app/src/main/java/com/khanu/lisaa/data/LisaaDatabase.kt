package com.khanu.lisaa.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.khanu.lisaa.data.dao.CommandUsageDao
import com.khanu.lisaa.data.dao.ConversationDao
import com.khanu.lisaa.data.dao.NoteDao
import com.khanu.lisaa.data.dao.PreferenceDao
import com.khanu.lisaa.data.entity.CommandUsageEntity
import com.khanu.lisaa.data.entity.ConversationEntity
import com.khanu.lisaa.data.entity.NoteEntity
import com.khanu.lisaa.data.entity.PreferenceEntity

/**
 * Lisaa ka poora local memory store. Version 2 (Module 3) me do naye cheezein
 * aayi: notes ab category ke sath aate hain (goal/project/general), aur ek nayi
 * command_usage table frequently-used commands/apps track karti hai.
 *
 * MIGRATION_1_2 purana data (Module 2 se) safe rakhta hai — koi destructive
 * reset nahi hota, user ki purani conversation history/notes/preferences intact
 * rehte hain.
 */
@Database(
    entities = [
        ConversationEntity::class,
        NoteEntity::class,
        PreferenceEntity::class,
        CommandUsageEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class LisaaDatabase : RoomDatabase() {

    abstract fun conversationDao(): ConversationDao
    abstract fun noteDao(): NoteDao
    abstract fun preferenceDao(): PreferenceDao
    abstract fun commandUsageDao(): CommandUsageDao

    companion object {
        @Volatile
        private var INSTANCE: LisaaDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE notes ADD COLUMN category TEXT NOT NULL DEFAULT 'general'"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS command_usage (" +
                        "actionKey TEXT NOT NULL PRIMARY KEY, " +
                        "count INTEGER NOT NULL, " +
                        "lastUsed INTEGER NOT NULL)"
                )
            }
        }

        fun getInstance(context: Context): LisaaDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    LisaaDatabase::class.java,
                    "lisaa_memory.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build().also { INSTANCE = it }
            }
    }
}
