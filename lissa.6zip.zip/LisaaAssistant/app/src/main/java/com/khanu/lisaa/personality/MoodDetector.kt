package com.khanu.lisaa.personality

import java.util.Locale

/**
 * Lightweight, fully offline mood detector — koi AI/LLM API call nahi hoti.
 * User ke bole gaye text me Hindi (Roman script) aur English dono ke common
 * emotional keywords dhoondhta hai. Same keyword-matching style jo project
 * commands ke liye bhi use karta hai (CommandInterpreter) — fast, bina internet
 * ke kaam karta hai, aur codebase ke sath consistent hai.
 *
 * Detection order jaan-boojh kar aisa hai: stronger/negative emotions (sad,
 * lonely, angry, tired) pehle check hoti hain, phir positive/energetic
 * (excited, happy), phir context states (working, relaxed) — taaki mixed
 * utterance me emotional state ko priority mile.
 */
object MoodDetector {

    private val sadWords = listOf(
        "udaas", "dukhi", "rona", "roya", "royi", "bura lag",
        "dil toot", "pareshan hoon", "sad", "upset", "depressed",
        "hurt", "cry", "crying", "heartbroken", "down"
    )

    private val lonelyWords = listOf(
        "akela", "akeli", "akelapan", "lonely", "koi nahi hai",
        "miss kar raha", "miss kar rahi", "isolated"
    )

    private val angryWords = listOf(
        "gussa", "chidh", "naraz", "irritate", "angry", "frustrated",
        "chid gaya", "chid gayi", "pagal kar diya"
    )

    private val tiredWords = listOf(
        "thak gaya", "thak gayi", "thaki", "thaka", "tired", "exhausted",
        "neend aa rahi", "sona hai", "so jaun"
    )

    private val excitedWords = listOf(
        "excited", "josh", "pumped", "thrilled", "can't wait", "bahut josh"
    )

    private val happyWords = listOf(
        "khush", "khushi", "mast hoon", "badhiya", "shandar", "zabardast",
        "happy", "yay", "great news", "achha laga", "superb",
        "awesome", "amazing", "khushkhabri"
    )

    private val workingWords = listOf(
        "kaam", "office", "deadline", "meeting", "padhai", "exam", "study",
        "busy", "working", "project", "assignment", "presentation", "target"
    )

    private val relaxedWords = listOf(
        "relax", "aaram se", "chill", "free hoon", "fursat", "peaceful",
        "shanti se", "koi tension nahi"
    )

    /** User ke text se sabse relevant mood category return karta hai. */
    fun detect(text: String): Mood {
        val t = text.lowercase(Locale.getDefault())

        return when {
            sadWords.any { t.contains(it) } -> Mood.SAD
            lonelyWords.any { t.contains(it) } -> Mood.LONELY
            angryWords.any { t.contains(it) } -> Mood.ANGRY
            tiredWords.any { t.contains(it) } -> Mood.TIRED
            excitedWords.any { t.contains(it) } -> Mood.EXCITED
            happyWords.any { t.contains(it) } -> Mood.HAPPY
            workingWords.any { t.contains(it) } -> Mood.WORKING
            relaxedWords.any { t.contains(it) } -> Mood.RELAXED
            else -> Mood.NEUTRAL
        }
    }
}
