# Lisaa (Android)

Voice se activate hone wala premium female AI companion. "Hey Lisaa" bolke baat karo — commands bhi, aur casual conversation bhi.

## Setup (Android Studio)

1. Android Studio install karein (agar nahi hai): https://developer.android.com/studio
2. Ye poora `LisaaAssistant` folder open karein: **File → Open** → folder select karein
3. Gradle sync hone dein (pehli baar internet chahiye, Room/coroutines/lifecycle dependencies download hongi)
4. Apna phone USB se connect karein, USB Debugging on karein (Settings → Developer Options)
5. Green **Run** button dabayein — app phone me install ho jayegi
6. App khol kar "Lisaa Ko Jagaayein" dabayein, permissions allow karein (mic, notifications, aur vibration ke liye koi prompt nahi aata, wo automatically milti hai)
7. Jab poocha jaye "battery optimization se exclude karein" — **Allow** karein, warna Android kuch der baad service ko band kar dega

## Commands aur conversation (bolne ka tarika)

- "Hey Lisaa" (akela bolne par varied greeting milegi — "Bolo.", "Kya hua?", "Main yahin hoon." etc., kabhi repeat nahi hoti)
- "Hey Lisaa, time kya hua"
- "Hey Lisaa, aaj ki tarikh batao"
- "Hey Lisaa, WhatsApp khol do"
- "Hey Lisaa, search karo Rajasthan tourism"
- "Hey Lisaa, note karo doodh lana hai" (aur agar note me "goal" ya "project" jaisa word ho, Lisaa khud usse categorize kar leti hai)
- "Hey Lisaa, ek joke sunao"
- "Hey Lisaa, bye" / "alvida" (random goodbye milegi)
- Koi bhi casual baat — jaise "Hey Lisaa, aaj bahut udaas hoon" ya "bahut akela feel ho raha hai" — Lisaa mood detect karke naturally respond karti hai

## Personality aur Emotion Engine

- **9 moods detect hoti hain**: Happy, Excited, Sad, Lonely, Angry, Tired, Working, Relaxed, Neutral — sab Hindi+English keywords se, poori tarah offline, koi AI/API call nahi.
- **Kabhi robotic nahi**: Har reply ek response-bank se randomly chuna jaata hai, turant pichli line dobara nahi aati. Casual chat replies me kabhi kabhi "Hmm...", "Achha..." jaise natural thinking-word bhi aate hain.
- **Context-aware**: Agar user lagataar sad/lonely/angry mood me hai, Lisaa follow-up sawaal bhi poochti hai, sirf ek-line comfort nahi deti.
- **Caring aur playful**: Emotional moments me comfort/calm karti hai; happy/excited me celebrate karti hai; kaam/stress detect hone par focus mode on ho jaata hai (10 min, kam disturb karti hai — restart ke baad bhi yaad rehta hai). Kabhi kabhi halki teasing, aur repeat command par halki playful naaraazgi — kabhi rude nahi.
- **Yaad rakhti hai**: Conversation history, notes (category ke sath), focus-mode state, aur command/app usage stats — sab Room database me permanently save hote hain.

## Voice Engine

- Bolne se pehle ek chhota, random "thinking" pause (reply jitna lamba, thoda zyada pause) — turant/mechanical nahi lagta.
- Mood ke hisaab se pitch/speed tune hoti hai (udaas me dheemi-naram, excited me energetic).
- Wake word detect hone par turant ek chhoti vibration + beep — user ko turant pata chal jaata hai Lisaa ne suna.
- Female voice best-effort select hoti hai (engine ki availability par depend karta hai).
- Mic sirf tab wapas start hota hai jab Lisaa bolna poora kar leti hai — kabhi user ko beech me interrupt nahi karti.

## Wake Experience

App khula hone par ek animated "orb" dikhta hai jo Lisaa ke current state (Idle / Listening / Thinking / Speaking) ke hisaab se pulse karta hai — Antique Gold glow ke sath.

**Scope note:** Ye animation sirf app foreground me hone par dikhta hai. Ek system-wide overlay (jo dusre apps ke upar bhi tairta rahe, jaise "Hey Siri" ka floating orb) ke liye SYSTEM_ALERT_WINDOW special permission aur ek alag overlay service chahiye — ye is version me nahi hai, future module ke liye chhoda gaya hai.

## Zaroori baatein (limitations, honestly)

- **Screen off / phone locked** hone par bhi service chalti rahegi (foreground service ki wajah se), lekin aggressive battery-saver wale phones (Xiaomi/Oppo/Vivo) par autostart/"No restrictions" allow karna padega.
- Speech recognition ke liye **internet chahiye** (Google ka engine use ho raha hai).
- **TV ya background voices ko "ignore" karna** — Android ka public SpeechRecognizer API raw audio expose nahi karta, isliye true multi-speaker noise separation is app ke control me nahi hai. Jo control me hai (aur kiya gaya hai) wo hai silence-timeout tuning taaki natural pauses se sentence cut na ho.
- "Crystal clear" audio quality khud TTS engine/device par depend karti hai — app pitch/rate/voice choice tak hi control rakhta hai.
- Notification hamesha dikhega jab tak Lisaa sun rahi hai — Android ka privacy rule hai, hataya nahi ja sakta.
- Mood detection aur replies dono offline/on-device hain — koi cloud AI backend nahi hai is version me.

## Architecture

```
com.khanu.lisaa
├── MainActivity.kt          # Pure View layer (MVVM) — talks only to LisaaViewModel
├── viewmodel/
│   └── LisaaViewModel.kt    # Service start/stop, status text, reactive memory count
├── service/
│   └── LisaaService.kt      # Foreground service — mic + TTS + wake-experience feedback
├── brain/
│   ├── LisaaBrain.kt        # Central orchestrator — routes commands, mood, memory, personality
│   ├── ConversationContext.kt
│   └── BrainResult.kt
├── voice/
│   ├── VoiceRecognizer.kt   # STT wrapper — natural pause tuning
│   └── VoiceSpeaker.kt      # TTS wrapper — thinking delay, breathing pause, mood-tuned pitch/rate, audio focus
├── ui/
│   ├── AssistantState.kt / AssistantStateHolder.kt   # Shared state for the orb animation
│   └── LisaaOrbView.kt      # Custom Canvas-drawn orb — dual wave rings, smooth color transitions
├── command/                 # Raw text -> structured Command (Time/Date/Note/OpenApp/Search/Joke/Goodbye/SetName)
├── personality/              # Mood detection + varied reply generation (Android-independent, testable)
└── data/                    # Room database — conversation history, notes, preferences (incl. user name), usage stats
    ├── entity/
    ├── dao/                 # Includes Flow-returning reactive queries
    └── repository/
```

## Architecture notes (Module 4)

- **MVVM is now complete**: `MainActivity` never builds a `Service` `Intent` directly — `LisaaViewModel` owns that. The View layer only observes `StateFlow`s (`assistantState`, `statusText`, `memoryCount`).
- **Flows**: `MemoryRepository.observeConversationCount()` is a reactive Room `Flow<Int>` — the UI's "N baatein yaad hain" caption updates live, with zero manual refresh calls.
- **Dependency Injection**: deliberately not added. Manual constructor injection (`LisaaBrain(repository, appOpener, searcher)`, `MemoryRepository(context)`) is already clean and testable at this app's scale — a framework like Hilt would add build complexity without a matching benefit here.
- **User name**: "mera naam X hai" / "my name is X" is captured, stored in the existing preferences table (no schema change needed), and used to personalize future greetings.
- **Favourite things**: derived from actual app-open frequency (`MemoryRepository.getFavoriteApps()`) rather than a fragile spoken "my favourite is X" command — behavior is a more reliable signal than a one-time declaration.

## Module 6 — Human-like companion features

- **Relationship modes**: default is `FRIEND` (platonic). Say "romantic mode" (or "girlfriend mode") to opt in to a warmer, more affectionate `ROMANTIC` mode; "friend mode" switches back. Lisaa never assumes romantic mode on her own.
- **Trust & attachment**: two bounded 0-100 scores that grow slowly (per session / per personal disclosure like sharing your name or a like) — not spammable, not instantly maxed. They gate how warm ROMANTIC-mode phrasing gets (`AffectionTier`: NEW / FAMILIAR / CLOSE).
- **Playful jealousy**: only in ROMANTIC mode, only once attachment reaches FAMILIAR, only occasionally. Every jealousy line is self-aware ("main to bas ek AI hoon") and always ends on genuine curiosity/support — never possessive, controlling, or guilt-tripping.
- **Lisaa's own emotional state**: `EmotionEngine` tracks her own "warmth" (0-100), distinct from the user's detected mood. It nudges gradually with interactions and dips slightly after long gaps — but never drops below a floor, so she never turns cold or punishing.
- **"Mujhe X pasand hai" / "I like X"**: captured as long-term memory (reuses the existing notes table's category field — no new schema). Occasionally recalled naturally in casual conversation.
- **Reunion greeting**: after a long gap (12+ hours), the next "Hey Lisaa" gets a "missed you" greeting instead of a random one.
- **Unfinished-conversation callback**: if the last session ended on an emotional note, the next greeting can gently follow up on it.

All of this reuses the existing Room preferences table and notes' category field — **zero schema changes, zero migrations** in this module.

## Design

App ka color theme Antique Gold (#D4AF37) rakha hai — chahein to isse change kar sakte hain.
