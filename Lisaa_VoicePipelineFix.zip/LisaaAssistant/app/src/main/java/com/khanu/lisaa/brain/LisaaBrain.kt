package com.khanu.lisaa.brain

import com.khanu.lisaa.command.Command
import com.khanu.lisaa.command.CommandInterpreter
import com.khanu.lisaa.data.repository.MemoryRepository
import com.khanu.lisaa.emotion.EmotionEngine
import com.khanu.lisaa.personality.GreetingContext
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.personality.MoodDetector
import com.khanu.lisaa.personality.PersonalityEngine
import com.khanu.lisaa.relationship.RelationshipEngine
import com.khanu.lisaa.relationship.RelationshipMode
import com.khanu.lisaa.util.Constants
import kotlin.random.Random
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Lisaa ka "dimaag" — poori conversation ka orchestrator.
 *
 * Ye class Module 1 (CommandInterpreter, MoodDetector, PersonalityEngine),
 * Module 2 (MemoryRepository), aur Module 6 (RelationshipEngine, EmotionEngine)
 * ko jodti hai, aur Service ko sirf ek saaf [BrainResult] deti hai — bolna kya
 * hai, kis mood me. Service isse sirf itna maangta hai; mic/TTS/notification
 * jaisi Android-specific cheezon se ye class bilkul anjaan hai (isliye testable
 * hai — koi Context/Service dependency nahi).
 *
 * Responsibilities:
 *  - Conversation Flow: [handleUtterance] wake-word se lekar reply tak
 *  - Emotion Engine (user): [MoodDetector] ka orchestration
 *  - Emotion Engine (Lisaa khud): [EmotionEngine] ka orchestration
 *  - Relationship Engine: [RelationshipEngine] ka orchestration — trust,
 *    attachment, mode, jealousy gating
 *  - Memory Context: [ConversationContext] + [MemoryRepository]
 *  - Personality Engine: [PersonalityEngine] ka orchestration
 *  - Response Selection: PersonalityEngine se sahi reply chunna
 *  - Command Routing: [CommandInterpreter] ke Command par based routing
 *  - Context Awareness: mood streak, repeat-command detection, focus mode,
 *    long-absence detection, fact recall
 *
 * @param appOpener Real app-launch action Service se inject hoti hai (PackageManager
 *                  access chahiye, isliye ye Brain ke andar nahi ho sakta) — true
 *                  return karta hai agar app mil gaya aur khul gaya.
 * @param searcher  Real web-search action, Service se inject.
 */
class LisaaBrain(
    private val repository: MemoryRepository,
    private val appOpener: (String) -> Boolean,
    private val searcher: (String) -> Unit
) {
    private val personality = PersonalityEngine()
    private val context = ConversationContext()

    private lateinit var relationshipEngine: RelationshipEngine
    private lateinit var emotionEngine: EmotionEngine

    // Reuse: har command par naya SimpleDateFormat banana zaroori nahi — object reuse
    // se thoda GC pressure kam hota hai (Module 3 performance pass ka hissa).
    private val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
    private val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())

    // ROMANTIC mode me kabhi kabhi trigger hone wali halki, self-aware jealousy
    // ke liye keywords — kabhi possessive/controlling nahi, sirf cute/playful.
    private val jealousyTriggerWords = listOf(
        "dost ke sath", "kisi aur se baat", "kisi se milne", "date pe",
        "girlfriend", "boyfriend"
    )

    /** Service startup par pichla context — mood, focus mode, naam, relationship, emotion — sab memory se load karta hai. */
    suspend fun loadContext() {
        repository.lastMood()?.let { context.updateMood(it) }
        context.focusModeUntil = repository.getFocusModeUntil()
        context.userName = repository.getUserName()
        context.isFirstEverSession = repository.conversationCount() == 0
        context.lastSeenAt = repository.getLastSeenAt()

        relationshipEngine = RelationshipEngine(
            mode = repository.getRelationshipMode(),
            trust = repository.getTrustLevel(),
            attachment = repository.getAttachmentLevel()
        )
        emotionEngine = EmotionEngine(warmth = repository.getWarmth())

        // Naya session shuru hone par (pehli baar nahi) bond thoda gehra hota hai,
        // aur lambe gap ka thoda emotional asar bhi apply hota hai.
        if (context.lastSeenAt != 0L) {
            val hoursSinceLastSeen = (System.currentTimeMillis() - context.lastSeenAt) / 3_600_000L
            relationshipEngine.onNewSession()
            emotionEngine.applyInactivityDecay(hoursSinceLastSeen)
            persistRelationshipState()
            persistEmotionState()
        }
    }

    /**
     * Fast, non-suspending check — Service isse turant wake-word acknowledgment
     * (activation tone/vibration) ke liye use karta hai, [handleUtterance] chalne
     * se pehle hi.
     */
    fun containsWakeWord(text: String): Boolean = matchWakeWord(text) != null

    /**
     * Poora recognized utterance process karta hai. Wake word na mile to null
     * return karta hai (Service ko chupchap sunte rehna chahiye).
     */
    suspend fun handleUtterance(rawText: String): BrainResult? {
        val wake = matchWakeWord(rawText) ?: return null
        val commandText = rawText.replace(wake, "").trim()

        val result = if (commandText.isBlank()) {
            handleGreeting(rawText)
        } else {
            processCommand(commandText)
        }
        touchLastSeen()
        return result
    }

    private fun matchWakeWord(text: String): String? =
        Constants.WAKE_WORDS.firstOrNull { text.contains(it) }

    private suspend fun handleGreeting(rawText: String): BrainResult {
        val hoursSinceLastSeen = if (context.lastSeenAt == 0L) {
            0L
        } else {
            (System.currentTimeMillis() - context.lastSeenAt) / 3_600_000L
        }
        val greetingContext = GreetingContext(
            recentMood = context.recentMood,
            userName = context.userName,
            isFirstMeeting = context.isFirstEverSession,
            isLongAbsence = !context.isFirstEverSession && hoursSinceLastSeen >= EmotionEngine.LONG_GAP_HOURS,
            relationshipMode = relationshipEngine.currentMode(),
            affectionTier = relationshipEngine.affectionTier()
        )
        val reply = personality.greeting(greetingContext)
        context.isFirstEverSession = false

        // Greeting ka TTS tone Lisaa ke apne emotional state (EmotionEngine) se
        // aata hai — sirf user ka detected mood mirror karne ke bajaye, uski
        // apni "warmth" bolti hai (Module 6 emotion-based voice integration).
        val toneMood = emotionEngine.toneMood()
        repository.remember(rawText, reply, toneMood)
        return BrainResult(reply, toneMood)
    }

    private suspend fun processCommand(commandText: String): BrainResult {
        val now = System.currentTimeMillis()
        val mood = MoodDetector.detect(commandText)
        val isRepeat = commandText == context.lastCommandText &&
            (now - context.lastCommandTime) < Constants.REPEAT_COMMAND_WINDOW_MS
        val focusActive = now < context.focusModeUntil

        // Mood streak isi utterance ke hisaab se update — reply-shaping se pehle,
        // taaki follow-up-question logic sahi streak count dekhe.
        context.updateMood(mood)
        emotionEngine.reactTo(mood)
        persistEmotionState()

        if (mood == Mood.WORKING) {
            context.focusModeUntil = now + Constants.FOCUS_MODE_DURATION_MS
            repository.setFocusModeUntil(context.focusModeUntil)
        }

        val command = CommandInterpreter.parse(commandText)
        var reply = when (command) {
            is Command.Time -> personality.wrapTime(timeFormat.format(Date()))
            is Command.Date -> personality.wrapDate(dateFormat.format(Date()))
            is Command.Note -> handleNote(command.text)
            is Command.OpenApp -> handleOpenApp(command.appName)
            is Command.Search -> handleSearch(command.query)
            is Command.Joke -> {
                repository.recordUsage("joke")
                personality.wrapJoke()
            }
            is Command.Goodbye ->
                personality.farewell(relationshipEngine.currentMode(), relationshipEngine.affectionTier())
            is Command.SetName -> handleSetName(command.name)
            is Command.LikeSomething -> handleLikeSomething(command.thing)
            is Command.SetRelationshipMode -> handleSetRelationshipMode(command.modeKeyword)
            is Command.Unknown -> handleConversational(commandText, mood, focusActive)
        }

        // Priority: repeat-annoyance > emotional aside (functional command + strong
        // mood) > follow-up question (conversational + repeated emotional streak) >
        // light tease. Sirf ek hi extra kabhi lagti hai, taaki reply overloaded na ho.
        val isFunctionalCommand = command !is Command.Unknown && command !is Command.Goodbye
        val emotionalMoods = setOf(Mood.SAD, Mood.LONELY, Mood.ANGRY, Mood.TIRED)
        val followUpMoods = setOf(Mood.SAD, Mood.LONELY, Mood.ANGRY)

        reply = when {
            isRepeat -> "${personality.annoyedRepeat()} $reply"
            isFunctionalCommand && mood in emotionalMoods -> personality.attachEmotionalAside(reply, mood)
            !isFunctionalCommand && mood in followUpMoods ->
                personality.maybeAddFollowUp(reply, mood, context.moodStreak)
            else -> personality.maybeAddTease(reply, mood, focusActive)
        }

        context.lastCommandText = commandText
        context.lastCommandTime = now

        repository.remember(commandText, reply, mood)
        return BrainResult(reply, mood)
    }

    /**
     * Unknown/conversational utterances — jealousy (agar eligible + trigger words +
     * chance), pehle bataye gaye "like" ka natural recall, ya normal mood-based
     * chat — priority order me, taaki dono ek sath kabhi na aayein.
     */
    private suspend fun handleConversational(commandText: String, mood: Mood, focusActive: Boolean): String {
        if (relationshipEngine.jealousyEligible() && mentionsOtherPerson(commandText) &&
            Random.nextInt(100) < 40
        ) {
            return personality.wrapJealousy()
        }

        if (mood == Mood.NEUTRAL && !focusActive && Random.nextInt(100) < 15) {
            val likes = repository.getLikes()
            if (likes.isNotEmpty()) {
                return personality.wrapRecallLike(likes.random())
            }
        }

        return personality.wrapConversational(mood, focusActive)
    }

    private fun mentionsOtherPerson(text: String): Boolean {
        val t = text.lowercase(Locale.getDefault())
        return jealousyTriggerWords.any { t.contains(it) }
    }

    private suspend fun handleNote(text: String): String {
        if (text.isNotBlank()) {
            val category = inferNoteCategory(text)
            repository.addNote(text, category = category)
            repository.recordUsage("note")
            if (category != "general") {
                relationshipEngine.onPersonalDisclosure()
                persistRelationshipState()
            }
        }
        return personality.wrapNote(text)
    }

    /** Note ke text me "goal"/"target"/"project" jaise keywords dekh kar category tag karta hai. */
    private fun inferNoteCategory(text: String): String {
        val t = text.lowercase(Locale.getDefault())
        return when {
            t.contains("goal") || t.contains("target") -> "goal"
            t.contains("project") -> "project"
            else -> "general"
        }
    }

    private suspend fun handleSetName(name: String): String {
        if (name.isBlank()) return personality.wrapSetNameEmpty()
        val cleanName = name.trim().split(" ").firstOrNull()
            ?.replaceFirstChar { it.uppercase() } ?: return personality.wrapSetNameEmpty()
        repository.setUserName(cleanName)
        context.userName = cleanName
        relationshipEngine.onPersonalDisclosure()
        persistRelationshipState()
        return personality.wrapSetName(cleanName)
    }

    private suspend fun handleLikeSomething(thing: String): String {
        if (thing.isBlank()) return personality.wrapLikeEmpty()
        repository.addNote(thing, category = "like")
        relationshipEngine.onPersonalDisclosure()
        persistRelationshipState()
        return personality.wrapLikeSaved(thing)
    }

    private suspend fun handleSetRelationshipMode(modeKeyword: String): String {
        val newMode = if (modeKeyword == "romantic") RelationshipMode.ROMANTIC else RelationshipMode.FRIEND
        relationshipEngine.setMode(newMode)
        persistRelationshipState()
        return personality.wrapRelationshipModeChanged(newMode)
    }

    private suspend fun handleOpenApp(appName: String): String {
        if (appName.isBlank()) return personality.wrapOpenAppEmpty()
        val found = appOpener(appName)
        return if (found) {
            repository.recordUsage("open:$appName")
            personality.wrapOpenAppFound(appName)
        } else {
            personality.wrapOpenAppNotFound(appName)
        }
    }

    private suspend fun handleSearch(query: String): String {
        if (query.isBlank()) return personality.wrapSearchEmpty()
        searcher(query)
        repository.recordUsage("search")
        return personality.wrapSearch(query)
    }

    private suspend fun persistRelationshipState() {
        repository.setRelationshipMode(relationshipEngine.currentMode())
        repository.setTrustLevel(relationshipEngine.trustLevel())
        repository.setAttachmentLevel(relationshipEngine.attachmentLevel())
    }

    private suspend fun persistEmotionState() {
        repository.setWarmth(emotionEngine.currentWarmth())
    }

    private suspend fun touchLastSeen() {
        context.lastSeenAt = System.currentTimeMillis()
        repository.setLastSeenAt(context.lastSeenAt)
    }
}
