package com.khanu.lisaa.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.khanu.lisaa.brain.BrainResult
import com.khanu.lisaa.brain.LisaaBrain
import com.khanu.lisaa.data.repository.MemoryRepository
import com.khanu.lisaa.ui.AssistantState
import com.khanu.lisaa.ui.AssistantStateHolder
import com.khanu.lisaa.util.Constants
import com.khanu.lisaa.voice.VoiceRecognizer
import com.khanu.lisaa.voice.VoiceSpeaker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * Lisaa ka background foreground service — mic aur TTS ko chalata hai, aur har
 * utterance ko [LisaaBrain] ko de deta hai. Ye class jaan-boojh kar thin
 * controller rakhi gayi hai: "kya bolna hai" ka poora decision LisaaBrain se
 * aata hai, ye class sirf Android APIs (mic, TTS, vibration, notification) ko
 * jodti hai.
 *
 * Thread note: SpeechRecognizer/TextToSpeech dono ko sirf usi thread se call
 * karna chahiye jispar wo bane the — isliye serviceScope Dispatchers.Main use
 * karta hai. Room ke suspend DAO calls (MemoryRepository ke andar, LisaaBrain
 * ke through) is se bhi safe hain kyunki Room unhe apne internal executor par
 * khud offload karta hai, chahe caller kisi bhi dispatcher par ho.
 */
class LisaaService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private lateinit var repository: MemoryRepository
    private lateinit var brain: LisaaBrain
    private lateinit var recognizer: VoiceRecognizer
    private lateinit var speaker: VoiceSpeaker

    private var vibrator: Vibrator? = null
    private var toneGenerator: ToneGenerator? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()

        repository = MemoryRepository(applicationContext)
        brain = LisaaBrain(
            repository = repository,
            appOpener = ::launchApp,
            searcher = ::launchSearch
        )
        vibrator = resolveVibrator()
        // ToneGenerator kabhi kabhi audio resource na milne par exception fekta hai —
        // runCatching se app crash nahi hoti, bas activation beep silently skip ho jaata hai.
        toneGenerator = runCatching { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70) }.getOrNull()

        speaker = VoiceSpeaker(applicationContext) { onSpeakingFinished() }
        recognizer = VoiceRecognizer(applicationContext, ::onTextRecognized)

        serviceScope.launch {
            brain.loadContext()
            beginListening()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                Constants.NOTIFICATION_CHANNEL_ID,
                "Lisaa Assistant",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(this, Constants.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Lisaa sun rahi hai")
            .setContentText("\"Hey Lisaa\" bol kar shuru karein")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        startForeground(Constants.NOTIFICATION_ID, notification)
    }

    private fun resolveVibrator(): Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as? Vibrator
        }

    private fun beginListening() {
        AssistantStateHolder.setState(AssistantState.LISTENING)
        recognizer.startListening()
    }

    /** VoiceRecognizer callback — recognizer khud is call ke baad naya session shuru nahi karta. */
    private fun onTextRecognized(text: String) {
        if (text.isBlank() || !brain.containsWakeWord(text)) {
            beginListening()
            return
        }

        // Wake word turant acknowledge — user ko turant pata chal jaaye Lisaa ne suna
        playActivationCue()
        AssistantStateHolder.setState(AssistantState.THINKING)

        serviceScope.launch {
            val result = brain.handleUtterance(text)
            if (result != null) {
                speak(result)
            } else {
                beginListening()
            }
        }
    }

    private fun speak(result: BrainResult) {
        AssistantStateHolder.setState(AssistantState.SPEAKING)
        speaker.speak(result.replyText, result.mood)
    }

    /** VoiceSpeaker isse tabhi call karta hai jab bolna poora ho chuka ho — mic sirf tab shuru hota hai. */
    private fun onSpeakingFinished() {
        beginListening()
    }

    private fun playActivationCue() {
        vibrator?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                it.vibrate(60)
            }
        }
        toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 120)
    }

    private fun launchApp(appName: String): Boolean {
        @Suppress("DEPRECATION")
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull {
            packageManager.getApplicationLabel(it).toString()
                .lowercase(Locale.getDefault()).contains(appName)
        }
        val launchIntent = match?.let { packageManager.getLaunchIntentForPackage(it.packageName) }
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    private fun launchSearch(query: String) {
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
        )
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
    }

    override fun onDestroy() {
        recognizer.destroy()
        speaker.shutdown()
        toneGenerator?.release()
        AssistantStateHolder.setState(AssistantState.IDLE)
        serviceScope.cancel()
        super.onDestroy()
    }
}
