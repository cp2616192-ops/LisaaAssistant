package com.khanu.lisaa.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import com.khanu.lisaa.util.Constants
import java.util.Locale

/**
 * Speech-to-text wrapper. Service ko SpeechRecognizer ki internal details
 * (RecognitionListener, retries, error handling) se matlab nahi rehta — bas
 * ek callback milta hai jab final text pehchana jaaye.
 *
 * THREAD NOTE: Android ka SpeechRecognizer sirf us thread par kaam karta hai
 * jispar wo create hua tha (aam taur par main thread). Is class ko hamesha
 * main thread se hi banaya aur call kiya jaana chahiye — LisaaService isi
 * wajah se apna coroutine scope Dispatchers.Main par rakhta hai.
 *
 * Natural pauses: EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS aur
 * EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS badha kar user ko
 * sentence poora karne ka zyada natural time milta hai — bolte hi turant cut
 * nahi hota.
 *
 * HONEST LIMITATION: Android ka public SpeechRecognizer API (ACTION_RECOGNIZE_SPEECH
 * flow) raw audio buffer expose nahi karta, isliye is class ke andar se "TV ya
 * background voice ignore karna" jaisa true multi-speaker noise separation
 * possible nahi hai — wo recognition engine (Google) ke internal VAD/noise
 * handling par depend karta hai. Jo yahan hamare control me hai wo hai
 * silence-timeout tuning, jo humne kiya hai.
 *
 * DEBUG INSTRUMENTATION: har stage par Log.d(Constants.DEBUG_TAG, ...) hai taaki
 * "wake word works, listening ends, Lisaa never speaks" jaise bugs ko Logcat me
 * exact callback tak trace kiya ja sake. Ye temporary diagnostic hai, feature nahi.
 */
class VoiceRecognizer(
    private val context: Context,
    private val onTextRecognized: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    fun startListening() {
        Log.d(Constants.DEBUG_TAG, "[1] VoiceRecognizer.startListening() called")

        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            Log.d(
                Constants.DEBUG_TAG,
                "VoiceRecognizer.startListening() - isRecognitionAvailable()=false, " +
                    "device/engine has no speech recognizer. Retrying in 2000ms."
            )
            handler.postDelayed({ startListening() }, 2000)
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // User ko poora vaakya bolne ka natural time dena — turant cut nahi karna.
            // (Pehle EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS=15000 tha jo onResults()
            // ko 15 second tak block karta tha — hata diya gaya. Ab sirf silence-length
            // extras hain jo sahi tarike se "turant cut mat karo" implement karte hain.)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                Log.d(Constants.DEBUG_TAG, "[2] RecognitionListener.onReadyForSpeech() - mic is ready")
            }

            override fun onBeginningOfSpeech() {
                Log.d(Constants.DEBUG_TAG, "[3] RecognitionListener.onBeginningOfSpeech() - user started talking")
            }

            override fun onRmsChanged(rmsdB: Float) {
                // Bahut frequent fire hota hai — jaan-boojh kar log nahi kiya, Logcat spam karega
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                Log.d(Constants.DEBUG_TAG, "[4] RecognitionListener.onEndOfSpeech() - user stopped talking, engine ab process kar raha hai")
            }

            override fun onError(error: Int) {
                Log.d(Constants.DEBUG_TAG, "[6] RecognitionListener.onError() - ${describeError(error)}")
                // No-speech / timeout jaise errors normal hain, bas dobara suno
                handler.postDelayed({ startListening() }, 700)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.lowercase(Locale.getDefault()).orEmpty()
                Log.d(
                    Constants.DEBUG_TAG,
                    "[5] RecognitionListener.onResults() - all matches=$matches, using text='$text'"
                )
                onTextRecognized(text)
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            speechRecognizer?.startListening(recognizerIntent)
            Log.d(Constants.DEBUG_TAG, "VoiceRecognizer.startListening() - speechRecognizer.startListening() dispatched successfully")
        } catch (e: Exception) {
            Log.d(Constants.DEBUG_TAG, "VoiceRecognizer.startListening() - EXCEPTION calling startListening(): ${e.message}")
            handler.postDelayed({ startListening() }, 1000)
        }
    }

    /** Raw SpeechRecognizer error int ko human-readable naam me convert karta hai — Logcat me cryptic numbers padhna mushkil hai. */
    private fun describeError(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "ERROR_NETWORK_TIMEOUT($error)"
        SpeechRecognizer.ERROR_NETWORK -> "ERROR_NETWORK($error)"
        SpeechRecognizer.ERROR_AUDIO -> "ERROR_AUDIO($error)"
        SpeechRecognizer.ERROR_SERVER -> "ERROR_SERVER($error)"
        SpeechRecognizer.ERROR_CLIENT -> "ERROR_CLIENT($error)"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "ERROR_SPEECH_TIMEOUT($error) - no speech detected in time"
        SpeechRecognizer.ERROR_NO_MATCH -> "ERROR_NO_MATCH($error) - speech heard but not recognized as text"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "ERROR_RECOGNIZER_BUSY($error)"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "ERROR_INSUFFICIENT_PERMISSIONS($error)"
        10 -> "ERROR_TOO_MANY_REQUESTS(10)"
        11 -> "ERROR_SERVER_DISCONNECTED(11)"
        12 -> "ERROR_LANGUAGE_NOT_SUPPORTED(12) - hi-IN may not be available on this device"
        13 -> "ERROR_LANGUAGE_UNAVAILABLE(13)"
        14 -> "ERROR_CANNOT_CHECK_SUPPORT(14)"
        15 -> "ERROR_CANNOT_LISTEN_TO_DOWNLOAD_EVENTS(15)"
        else -> "UNKNOWN_ERROR($error)"
    }

    fun destroy() {
        Log.d(Constants.DEBUG_TAG, "VoiceRecognizer.destroy() called")
        speechRecognizer?.destroy()
        speechRecognizer = null
        handler.removeCallbacksAndMessages(null)
    }
}
