package com.khanu.lisaa.voice

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import com.khanu.lisaa.personality.Mood
import com.khanu.lisaa.util.Constants
import java.util.Locale
import kotlin.random.Random

/**
 * Text-to-speech wrapper. Do cheezein add karta hai jo default Android TTS
 * khud nahi karta:
 *
 *  1. Bolne se pehle ek chhota, random "sochne" jaisa pause (reply jitna lamba,
 *     utna hi thoda zyada pause) — taaki jawab turant/mechanical na aaye.
 *  2. Mood ke hisaab se pitch/speed adjust karna — udaas/akela/thaka hua mood
 *     me dheemi aur naram awaaz, excited/happy me thodi zyada energetic.
 *  3. Bolna shuru hone se theek pehle ek chhoti "breathing" silence (TTS ki apni
 *     queue mein), mood ke hisaab se lambi/chhoti — insaan jaisi natural saans.
 *
 * Audio focus request karta hai speak karne se pehle taaki doosre app ka audio
 * overlap na ho — ye clipping/echo kam karne ka real, available mechanism hai
 * (asli "noise cancellation" nahi, lekin audio collision avoid karta hai).
 *
 * RELIABILITY REWRITE — teen cheezein fix hui:
 *  1. LANGUAGE FALLBACK: `tts?.language = Locale("hi","IN")` property syntax
 *     setLanguage() ka result CODE discard kar deta tha. Agar device par hi-IN
 *     TTS voice data hi nahi hai (bahut common, khaas kar English-locale
 *     devices/emulators par), TTS "ready" ho jaata tha lekin awaaz kabhi nahi
 *     aati thi — silent failure. Ab result explicitly check hota hai; agar
 *     LANG_MISSING_DATA ya LANG_NOT_SUPPORTED aaye, turant en-US par fallback
 *     hota hai (jo har Android device par guaranteed available hota hai).
 *  2. SPEAK() RESULT CHECK: tts.speak() ka return value ab check hota hai. Agar
 *     wo turant ERROR return kare, iska matlab hai UtteranceProgressListener
 *     ka koi callback is baar aayega hi nahi — pehle hum sirf intezaar karte
 *     rehte the; ab turant fallback/resume hota hai.
 *  3. SAFETY TIMEOUT: agar onDone/onError kisi bhi wajah se kabhi fire na hon
 *     (kuch OEM TTS engines me rare quirk), ek bounded safety timeout khud
 *     resume kar deta hai — pipeline kabhi permanently stuck nahi reh sakta.
 */
class VoiceSpeaker(
    private val context: Context,
    private val onReadyToListenAgain: () -> Unit
) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private val handler = Handler(Looper.getMainLooper())
    private var ready = false
    private var initAttempts = 0
    private var speakWaitAttempts = 0
    private var safetyTimeoutRunnable: Runnable? = null
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    // Deprecated overload use ho raha hai (minSdk 26 compatible, simple transient
    // focus ke liye kaafi hai) — isliye ek real listener chahiye, null nahi.
    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { /* no-op */ }

    init {
        initializeTts()
    }

    private fun initializeTts() {
        Log.d(Constants.DEBUG_TAG, "VoiceSpeaker.initializeTts() - creating TextToSpeech instance (attempt ${initAttempts + 1})")
        tts = TextToSpeech(context, this)
    }

    override fun onInit(status: Int) {
        Log.d(
            Constants.DEBUG_TAG,
            "[11] TextToSpeech.onInit() - status=${if (status == TextToSpeech.SUCCESS) "SUCCESS" else "ERROR($status)"}"
        )

        if (status != TextToSpeech.SUCCESS) {
            if (initAttempts < MAX_INIT_ATTEMPTS) {
                initAttempts++
                Log.d(Constants.DEBUG_TAG, "TextToSpeech.onInit() - retrying init, attempt $initAttempts/$MAX_INIT_ATTEMPTS")
                handler.postDelayed({ initializeTts() }, INIT_RETRY_DELAY_MS)
            } else {
                Log.d(Constants.DEBUG_TAG, "TextToSpeech.onInit() - gave up after $MAX_INIT_ATTEMPTS attempts, TTS will never become ready")
            }
            return
        }

        configureLanguage()
        selectFemaleVoiceIfAvailable()
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                Log.d(Constants.DEBUG_TAG, "[13] UtteranceProgressListener.onStart() - utteranceId=$utteranceId, audio should be playing now")
                cancelSafetyTimeout()
            }

            override fun onDone(utteranceId: String?) {
                Log.d(Constants.DEBUG_TAG, "[14] UtteranceProgressListener.onDone() - utteranceId=$utteranceId, speaking finished")
                cancelSafetyTimeout()
                abandonAudioFocus()
                handler.postDelayed({ onReadyToListenAgain() }, 250)
            }

            override fun onError(utteranceId: String?) {
                Log.d(Constants.DEBUG_TAG, "[15] UtteranceProgressListener.onError() - utteranceId=$utteranceId, TTS failed to speak")
                cancelSafetyTimeout()
                abandonAudioFocus()
                handler.postDelayed({ onReadyToListenAgain() }, 250)
            }
        })
        ready = true
        Log.d(Constants.DEBUG_TAG, "TextToSpeech.onInit() - ready=true, TTS fully initialized")
    }

    /**
     * RELIABILITY FIX: hi-IN TTS voice data har device par pehle se installed
     * nahi hoti. Result ab explicitly check hota hai; missing/unsupported hone
     * par en-US par fallback hota hai taaki Lisaa kam se kam bol to paaye.
     */
    private fun configureLanguage() {
        val engine = tts ?: return
        val hindiResult = engine.setLanguage(Locale("hi", "IN"))
        Log.d(Constants.DEBUG_TAG, "VoiceSpeaker.configureLanguage() - setLanguage(hi-IN) result=${describeLanguageResult(hindiResult)}")

        if (hindiResult == TextToSpeech.LANG_MISSING_DATA || hindiResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            val fallbackResult = engine.setLanguage(Locale.US)
            Log.d(
                Constants.DEBUG_TAG,
                "VoiceSpeaker.configureLanguage() - hi-IN unavailable on this device, falling back to en-US, " +
                    "result=${describeLanguageResult(fallbackResult)}"
            )
        }
    }

    private fun describeLanguageResult(result: Int): String = when (result) {
        TextToSpeech.LANG_AVAILABLE -> "LANG_AVAILABLE"
        TextToSpeech.LANG_COUNTRY_AVAILABLE -> "LANG_COUNTRY_AVAILABLE"
        TextToSpeech.LANG_COUNTRY_VAR_AVAILABLE -> "LANG_COUNTRY_VAR_AVAILABLE"
        TextToSpeech.LANG_MISSING_DATA -> "LANG_MISSING_DATA (voice data not downloaded on this device)"
        TextToSpeech.LANG_NOT_SUPPORTED -> "LANG_NOT_SUPPORTED"
        else -> "UNKNOWN($result)"
    }

    private fun selectFemaleVoiceIfAvailable() {
        val engine = tts ?: return
        val candidate: Voice? = runCatching {
            engine.voices?.firstOrNull {
                it.locale.language == "hi" && it.name.lowercase(Locale.US).contains("female")
            } ?: engine.voices?.firstOrNull {
                it.locale.language == "en" && it.name.lowercase(Locale.US).contains("female")
            }
        }.getOrNull()
        candidate?.let { engine.voice = it }
    }

    /** Reply bolti hai — thinking-delay, audio focus, aur mood-tuned pitch/rate ke sath. */
    fun speak(text: String, mood: Mood) {
        Log.d(Constants.DEBUG_TAG, "[10] VoiceSpeaker.speak() called - text='$text', mood=$mood, ready=$ready")

        if (!ready) {
            if (speakWaitAttempts < MAX_SPEAK_WAIT_ATTEMPTS) {
                speakWaitAttempts++
                Log.d(
                    Constants.DEBUG_TAG,
                    "VoiceSpeaker.speak() - TTS not ready yet, waiting (attempt $speakWaitAttempts/$MAX_SPEAK_WAIT_ATTEMPTS)"
                )
                handler.postDelayed({ speak(text, mood) }, 300)
            } else {
                Log.d(
                    Constants.DEBUG_TAG,
                    "VoiceSpeaker.speak() - TTS never became ready after ${MAX_SPEAK_WAIT_ATTEMPTS * 300}ms, " +
                        "giving up on this reply and resuming listening"
                )
                speakWaitAttempts = 0
                onReadyToListenAgain()
            }
            return
        }
        speakWaitAttempts = 0

        val lengthBonus = text.length.coerceAtMost(120) * 2L
        val baseDelay = Random.nextLong(Constants.THINKING_DELAY_MIN_MS, Constants.THINKING_DELAY_MAX_MS)
        val thinkingDelay = baseDelay + lengthBonus
        Log.d(Constants.DEBUG_TAG, "VoiceSpeaker.speak() - scheduling actual tts.speak() after ${thinkingDelay}ms thinking delay")

        handler.postDelayed({
            requestAudioFocus()
            applyMoodTone(mood)
            // Har call ko unique utteranceId — overlapping utterances kabhi ek doosre
            // ke onDone callback se confuse na hon (speech-loop/repeat bug prevention).
            val utteranceId = "${Constants.TTS_UTTERANCE_ID}_${System.nanoTime()}"

            // Engine ki max-length limit se zyada text bhejne par TTS ERROR de sakta
            // hai — is guard se wo edge case bhi crash/silent-fail nahi karta.
            val maxLen = TextToSpeech.getMaxSpeechInputLength()
            val safeText = if (text.length > maxLen) text.take((maxLen - 1).coerceAtLeast(0)) else text

            // Bolna shuru hone se theek pehle ek chhoti "breathing" silence — TTS ki
            // apni queue mein hi (Handler-delay se alag), taaki bilkul insaan jaisa
            // lage. Mood ke hisaab se lambi/chhoti hoti hai.
            tts?.playSilentUtterance(breathPauseFor(mood), TextToSpeech.QUEUE_FLUSH, null)

            Log.d(Constants.DEBUG_TAG, "[12] VoiceSpeaker - calling tts.speak(text='$safeText', utteranceId='$utteranceId')")
            val speakResult = tts?.speak(safeText, TextToSpeech.QUEUE_ADD, null, utteranceId)
            Log.d(
                Constants.DEBUG_TAG,
                "VoiceSpeaker - tts.speak() returned " +
                    if (speakResult == TextToSpeech.SUCCESS) "SUCCESS" else "ERROR($speakResult)"
            )

            if (speakResult == TextToSpeech.SUCCESS) {
                // RELIABILITY FIX: agar onDone/onError kisi wajah se kabhi fire na
                // hon, ye safety timeout khud resume kar deta hai.
                scheduleSafetyTimeout(safeText)
            } else {
                // speak() khud hi turant fail ho gaya — is utterance ke liye koi
                // callback kabhi aayega hi nahi. Turant resume karo, wait mat karo.
                Log.d(Constants.DEBUG_TAG, "VoiceSpeaker - tts.speak() failed synchronously, resuming listening immediately")
                abandonAudioFocus()
                onReadyToListenAgain()
            }
        }, thinkingDelay)
    }

    /** Bounded fallback — agar TTS callbacks kisi bhi wajah se kabhi na aayein, pipeline khud resume ho jaata hai. */
    private fun scheduleSafetyTimeout(text: String) {
        cancelSafetyTimeout()
        val timeoutMs = SAFETY_TIMEOUT_BASE_MS + (text.length * SAFETY_TIMEOUT_PER_CHAR_MS)
        val runnable = Runnable {
            Log.d(
                Constants.DEBUG_TAG,
                "VoiceSpeaker - SAFETY TIMEOUT fired after ${timeoutMs}ms, neither onDone nor onError arrived, forcing resume"
            )
            abandonAudioFocus()
            onReadyToListenAgain()
        }
        safetyTimeoutRunnable = runnable
        handler.postDelayed(runnable, timeoutMs)
    }

    private fun cancelSafetyTimeout() {
        safetyTimeoutRunnable?.let { handler.removeCallbacks(it) }
        safetyTimeoutRunnable = null
    }

    /** Udaas/akela/thaka hua mood me thodi lambi saans; excited/happy me chhoti. */
    private fun breathPauseFor(mood: Mood): Long = when (mood) {
        Mood.SAD, Mood.LONELY, Mood.TIRED -> Constants.BREATH_PAUSE_MAX_MS
        Mood.EXCITED, Mood.HAPPY -> Constants.BREATH_PAUSE_MIN_MS
        else -> (Constants.BREATH_PAUSE_MIN_MS + Constants.BREATH_PAUSE_MAX_MS) / 2
    }

    private fun applyMoodTone(mood: Mood) {
        val (pitch, rate) = when (mood) {
            Mood.SAD, Mood.LONELY, Mood.TIRED -> 0.95f to 0.90f
            Mood.HAPPY -> 1.08f to 1.05f
            Mood.EXCITED -> 1.12f to 1.10f
            Mood.ANGRY -> 0.98f to 0.95f
            Mood.WORKING -> 1.0f to 1.0f
            Mood.RELAXED -> 1.0f to 0.95f
            Mood.NEUTRAL -> 1.02f to 1.0f
        }
        tts?.setPitch(pitch)
        tts?.setSpeechRate(rate)
    }

    private fun requestAudioFocus() {
        @Suppress("DEPRECATION")
        audioManager?.requestAudioFocus(
            focusChangeListener, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
        )
    }

    private fun abandonAudioFocus() {
        @Suppress("DEPRECATION")
        audioManager?.abandonAudioFocus(focusChangeListener)
    }

    fun shutdown() {
        cancelSafetyTimeout()
        abandonAudioFocus()
        tts?.stop()
        tts?.shutdown()
        handler.removeCallbacksAndMessages(null)
    }

    companion object {
        private const val MAX_INIT_ATTEMPTS = 3
        private const val INIT_RETRY_DELAY_MS = 800L

        // 10 attempts * 300ms = ~3 second bounded wait before giving up gracefully
        private const val MAX_SPEAK_WAIT_ATTEMPTS = 10

        // Safety timeout: base + per-character allowance, generous enough for any
        // normal reply to finish speaking naturally before this ever fires.
        private const val SAFETY_TIMEOUT_BASE_MS = 4000L
        private const val SAFETY_TIMEOUT_PER_CHAR_MS = 80L
    }
}
