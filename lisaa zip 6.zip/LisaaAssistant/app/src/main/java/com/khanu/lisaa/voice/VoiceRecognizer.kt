package com.khanu.lisaa.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Speech-to-text wrapper. Service ko SpeechRecognizer ki internal details
 * (RecognitionListener, retries, error handling) se matlab nahi rehta — bas
 * ek callback milta hai jab final text pehchana jaaye.
 *
 * THREAD NOTE: Android ka SpeechRecognizer sirf us thread par kaam karta hai
 * jispar wo create hua tha (aam taur par main thread). Is class ko hamesha
 * main thread se hi banaya aur call kiya jaana chahiye — LisaaService isi
 * wajah se apna coroutine scope Dispatchers.Main par rakhta hai.
 *
 * Natural pauses: EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS aur
 * EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS badha kar user ko
 * sentence poora karne ka zyada natural time milta hai — bolte hi turant cut
 * nahi hota.
 *
 * HONEST LIMITATION: Android ka public SpeechRecognizer API (ACTION_RECOGNIZE_SPEECH
 * flow) raw audio buffer expose nahi karta, isliye is class ke andar se "TV ya
 * background voice ignore karna" jaisa true multi-speaker noise separation
 * possible nahi hai — wo recognition engine (Google) ke internal VAD/noise
 * handling par depend karta hai. Jo yahan hamare control me hai wo hai
 * silence-timeout tuning, jo humne kiya hai.
 */
class VoiceRecognizer(
    private val context: Context,
    private val onTextRecognized: (String) -> Unit
) {
    private var speechRecognizer: SpeechRecognizer? = null
    private val handler = Handler(Looper.getMainLooper())

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            handler.postDelayed({ startListening() }, 2000)
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // User ko poora vaakya bolne ka natural time dena — turant cut nahi karna
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 15000)
        }

        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull()?.lowercase(Locale.getDefault()).orEmpty()
                onTextRecognized(text)
            }

            override fun onError(error: Int) {
                // No-speech / timeout jaise errors normal hain, bas dobara suno
                handler.postDelayed({ startListening() }, 700)
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            handler.postDelayed({ startListening() }, 1000)
        }
    }

    fun destroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        handler.removeCallbacksAndMessages(null)
    }
}
